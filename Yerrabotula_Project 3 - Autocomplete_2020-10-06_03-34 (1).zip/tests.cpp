//
//  tests.cpp
/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 3 - autocomplete
*/
#include <iostream>
#include <fstream>
#include <string>
#include "AutocompleteList.h"
using namespace std;
// Tests getSize() on first constructor Test 1
bool size_test1() {
    AutocompleteList  list;  // empty list
    if (list.getSize() == 0) {
        return true;
    }
    return false;
}
// Tests getSize() on second constructor Test 2
bool size_test2() {
    int n = 10;
    AutocompleteList  list(n);  // empty list
    if (list.getSize() == 10) {
        return true;
    }
    return false;
}
// this tests the getsize() of third constructor
bool size_test3() {
    AutocompleteList list("small.txt");
    if (list.getSize() != 0) {
        return true;
    } 
    return false;
}
// testing the first constructor by comapring size.
bool first_Constructor() {
    AutocompleteList  list;  // empty list
    if (list.getSize() == 0) {
        return true;
    }
    return false;
}
// testing the second constructor by comapring size.
bool second_Constructor() {
    int n = 15;
    AutocompleteList  list(n);  
    if (list.getSize() == n) {
        return true;
    }
    return false;
}
// testing the second constructor with small value.
bool second_Constructor2() {
    int n = 1;
    AutocompleteList  list(n);  
    if (list.getSize() == n) {
        return true;
    }
    return false;
}
// check if the size is updated or not in third constructor. 
//test -1(tiny)
bool third_Construct1() {
    int n = 6;
    AutocompleteList list("tiny.txt"); //here getsize will be updated
    if (list.getSize() == n) { //comapre the getsize
        return true;
    }
    return false;
}
// check if the size is updated or not in third constructor. 
//test -2(small)
bool third_Construct2() {
AutocompleteList list("small.txt");
    int n = 10;
    if (list.getSize() == n) {
        return true;
    }
    return false;
}
// acessing the elements through square opertor[] to test it.
//test-1(tiny.txt)
bool square_operator1() {
    AutocompleteList list("tiny.txt");
    AutocompleteList list1 = list; // copy constructor
    int iterator = 0;
    while (iterator < list.getSize()) {
        if (list[iterator].query != list1[iterator].query || 
        list[iterator].weight != list1[iterator].weight) {
            return false;
        }
        iterator++;
    }
    return true;
}
// acessing the elements through square opertor[] to test it.
//test-2(small.txt)
bool square_operator2() {
    AutocompleteList list("small.txt");
    AutocompleteList list1 = list; // copy constructor
    int iterator = 0;
    while (iterator < list.getSize()) {
        if (list[iterator].query != list1[iterator].query || 
        list[iterator].weight != list1[iterator].weight) {
            return false;
        }
        iterator++;
    }
    return true;
}
// copies all the items of list to copyList
// after copying comapre original list size and copyList size.
bool copy_const1() {
    AutocompleteList list("tiny.txt");
    AutocompleteList copyList = list;  // copy constructor
    if (copyList.getSize() == list.getSize()) { // comparing size after copy.
        return true;
    }
    return false;
}
// copies all the items of list to copyList
// testing with second constructor and first
bool copy_const2() {
    int n = 100;
    AutocompleteList list(n); // size will be 100
    AutocompleteList copyList = list; // copying to copyList
    // copyList is a default construct initially
    // after copying the size should not be zero
    // and also check for original list size is equal to n or not.
    if (copyList.getSize() != 0 && list.getSize() == n) {
        return true;
    }
    return false;
}
// compares the query of both copy list and original list
bool copy_const3() {
    AutocompleteList list("tiny.txt");
    AutocompleteList list1 = list; // copy constructor
    int iterator = 0;
    while (iterator < list.getSize()) {
        if (list[iterator].query != list1[iterator].query) {
            return false;
        }
        iterator++;
    }
    return true;
}
// compares the weight of both copy list and original list
bool copy_const4() {
    AutocompleteList list("tiny.txt");
    AutocompleteList list1 = list; // copy constructor
    int iterator = 0;
    while (iterator < list.getSize()) {
        if (list[iterator].weight != list1[iterator].weight) {
            return false;
        }
        iterator++;
    }
    return true;
}
// edge case: testing on empty object for weight.
bool copy_const5() {
    AutocompleteList list;
    AutocompleteList list1 = list; // copy constructor
    int iterator = 0;
    while (iterator < list.getSize()) {
        if (list[iterator].weight != list1[iterator].weight) {
            return false;
        }
        iterator++;
    }
    return true;
}
// edge case: testing on empty object for query.
bool copy_const6() {
    AutocompleteList list;
    AutocompleteList list1 = list; //copy constructor
    int iterator = 0;
    while (iterator < list.getSize()) {
        if (list[iterator].query != list1[iterator].query) {
            return false;
        }
        iterator++;
    }
    return true;
}
// this tests both copy construct
// and equal operator ==.
bool equalOpt_test1() {
    AutocompleteList list("tiny.txt");  // original list
    AutocompleteList tempobj = list;  // copy constructor
    AutocompleteList equalopt("small.txt");  // another list.
    // initially tempobj was initized with list.
    // after initizing with equalopt, now the old contents will deleted.
    // and the contents of equalopt will be copied to tempObj.
    tempobj = equalopt; // equal operator
    // comapre size after using equaloperator.
    if (tempobj.getSize() == equalopt.getSize()) {
        return true;
    }
    return false;
}
// this tests both copy construct
// and equal operator ==.
// check for anothe case that is size should not equal
// original size after using equal operator.
bool equalOpt_test2() {
    AutocompleteList list("tiny.txt");
    AutocompleteList tempobj = list; // copy constructor
    AutocompleteList equalopt("small.txt");
    tempobj = equalopt; // equal operator
    // another test case for checking the size before equal operator
    // after equal operator.
    if (tempobj.getSize() != list.getSize()) {
        return true;
    }
    return false;
}
// comparing the query and weight of object after doing equal opertor operation.
bool equalOpt_test3() {
    AutocompleteList list("tiny.txt");
    AutocompleteList tempobj = list; // copy constructor
    AutocompleteList equalopt("small.txt");
    tempobj = equalopt; // equal operator
    int iterator = 0;
    while (iterator < tempobj.getSize()) {
        if (tempobj[iterator].query != equalopt[iterator].query || tempobj[iterator].weight != equalopt[iterator].weight) {
            return false;
        }
        iterator++;
    }
    return true;
}
// error check 1: for numberOfMatches function.
// check if the prefix is empty string 
// function should return 0.
bool num_matches1() {
    AutocompleteList list("tiny.txt");
    int returnVal = list.numberOfMatches(""); // stores return value
    if (returnVal == 0) { // checks if it is zero
        return true;
    }
    return false;
}
// error check2: for numberOfMatches function.
// checks if the sortType is not equal to lex 
// if yes function should return zero.
bool num_matches2() {
    AutocompleteList list; // creating obj with first constructor.
   // sort type will be none here.
    int returnVal = list.numberOfMatches("pret");  // stores return val.
    if (returnVal == 0) { // compares the two values.
        return true;
    }
    return false;
}
// error check3: for numberOfMatches function.
// return zero if prefix(a valid word) not present in the file.
bool num_matches3() {
    AutocompleteList list("wiktionary.txt");  // third constructor
    int returnVal = list.numberOfMatches("New York");  // store returnVal
    if (returnVal == 0) { // compares the values
        return true;
    }
    return false;
}
// error check4: for numberOfMatches function.
// return non zero value  if prefix(a valid word) is present in the file.
bool num_matches4() {
    AutocompleteList list("wiktionary.txt");
    int returnVal = list.numberOfMatches("start");
    if (returnVal != 0) {
        return true;
    }
    return false;
}
// error check1: if the prefix is an empty string
// the function should return zero.
bool all_matches1() {
    AutocompleteList list("tiny.txt");
    int n = 10;
    AutocompleteList emptylist(n);
    emptylist = list.allMatches("");  // sending empty string
   if (emptylist.getSize() == 0){  // comparing the vals
       return true;
   } 
   return false;
}
// returns the non empty object of AutocompleteList.
// IF The prefix is found in the file.
// size will be a non zero so check for size.
bool all_matches2() {
    AutocompleteList list("small.txt");
    AutocompleteList emptylist;
    emptylist = list.allMatches("hor");
    if (emptylist.getSize() != 0) {
        return true;
    }
    return false;
}
// print function visual testing1.
void print_test1() {
    cout << "visual testing: " << endl;
    cout << "fileName: wiktionary.txt" << endl;
    cout << "search: pret " << endl;
    AutocompleteList object("wiktionary.txt");
    AutocompleteList copyObject;
    copyObject = object.allMatches("pret");
    copyObject.print();
    cout << endl << endl;
    cout << "visual testing: " << endl;
    cout << "fileName: wiktionary.txt" << endl;
    cout << "search: start " << endl;
    copyObject = object.allMatches("start");
    copyObject.print();
    cout << endl << endl;
}
// print functio visual testing print_test2
// edge case: sending the prefix that's 
// not present in the file.
void print_test2() {
    cout << "visual testing: " << endl;
    AutocompleteList object("tiny.txt");
    AutocompleteList copyObject;
    cout << "fileName : tiny.txt" << endl;
    cout << "search: New York " << endl;
    copyObject = object.allMatches("New York");
    copyObject.print();
    copyObject = object.allMatches("start");
      cout << "fileName : tiny.txt" << endl;
    cout << "search: start " << endl;
    copyObject.print();
    cout << "prints nothing because prefix is not present in file" << endl;
    cout << endl << endl;
}
int main() {
    int passed = 0;
    int failed = 0;
      // Run tests
    if (size_test1()) {
        passed++;
    } else {
        cout << "size_test1 failed" << endl;
        failed++;
    }
    if (size_test2()) {
        passed++;
    } else {
        cout << "size_test2 failed" << endl;
        failed++;
    }
    if (third_Construct1()) {
        passed++;
    } else {
        cout << "third_Construct1 failed" << endl;
        failed++;
    }
    if (third_Construct2()) {
        passed++;
    } else {
        cout << "third_Construct2 failed" << endl;
        failed++;
    }
    if (square_operator1()) {
        passed++;
    } else {
        cout << "square_operator1 failed" << endl;
        failed++;
    }
    if (square_operator2()) {
        passed++;
    } else {
        cout << "square_operator2 failed" << endl;
        failed++;
    }
    if (copy_const1()) {
        passed++;
    } else {
        cout << "copy_const1() failed" << endl;
        failed++;
    }
    if (copy_const2()) {
        passed++;
    } else {
        cout << "copy_const2 failed" << endl;
        failed++;
    }
    if (copy_const3()) {
        passed++;
    } else {
        cout << "copy_const3 failed" << endl;
        failed++;
    }
    if (copy_const4()) {
        passed++;
    } else {
        cout << "copy_const4 failed" << endl;
        failed++;
    }
    if (copy_const5()) {
        passed++;
    } else {
        cout << "copy_const5 failed" << endl;
        failed++;
    }
    if (copy_const6()) {
        passed++;
    } else {
        cout << "copy_const6 failed" << endl;
        failed++;
    }
    if (equalOpt_test1()) {
        passed++;
    } else {
        cout << "equalOpt_test1 failed" << endl;
        failed++;
    }
    if (equalOpt_test2()) {
        passed++;
    } else {
        cout << "equalOpt_test2 failed" << endl;
        failed++;
    }
    if (equalOpt_test3()) {
        passed++;
    } else {
        cout << "equalOpt_test3 failed" << endl;
        failed++;
    }
    if (size_test3()) {
        passed++;
    } else {
        cout << "size_test3 failed" << endl;
        failed++;
    }
    if (first_Constructor()) {
        passed++;
    } else {
        cout << "first_Constructor failed" << endl;
        failed++;
    }
    if (second_Constructor()) {
        passed++;
    } else {
        cout << "second_Constructor failed" << endl;
        failed++;
    }
    if (second_Constructor2()) {
        passed++;
    } else {
        cout << "second_Constructor2 failed" << endl;
        failed++;
    }
    if (num_matches1()) {
        passed++;
    } else {
         cout << "num_matches1 failed" << endl;
        failed++;
    }
    if (num_matches2()) {
        passed++;
    } else {
         cout << "num_matches2 failed" << endl;
        failed++;
    }
    if (num_matches3()) {
        passed++;
    } else {
         cout << "num_matches3 failed" << endl;
        failed++;
    }
    if (num_matches4()) {
        passed++;
    } else {
         cout << "num_matches4 failed" << endl;
        failed++;
    }
    if (all_matches1()) {
        passed++;
    } else {
         cout << "all_matches1 failed" << endl;
        failed++;
    }
    if (all_matches2()) {
        passed++;
    } else {
         cout << "all_matches2 failed" << endl;
        failed++;
    }
    print_test1();
    passed++;
    print_test2();
    passed++;
    cout << "Tests passed: " << passed << endl;
    cout << "Tests failed: " << failed << endl;
    return 0;
}
