// AutocompleteList.h
//
/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 3 - autocomplete
*/
#pragma once

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <exception>

using namespace std;

struct Term {
    string query;
    long long int weight;
    // need this for autograding
    bool operator==(const Term& term) const {
        return (query == term.query && weight == term.weight);
    }
};

//
// AutocompleteList
//
class AutocompleteList {
 private:
    //
    // Private member variables for the abstraction.
    // This implementation uses a low-level C array, terms, to store a list of
    // Terms.  As a result, you must also keep track of the number of elements
    // stored (size).
    //
    Term* terms;  // pointer to a C-style array
    int size;  // number of elements in the array
    string sortType;  // records how list is sorted
    // private member function
    // finds the prefix .
    bool prefixCheck(string word, string prefix) {
      string check;
      check = word.substr(0, prefix.size()); // stores the substring
      if (prefix == check) {  // compares prefix with substring
          return true;
      }
      return false;
    }
    //
    // Private member function.
    // Returns the index of the first word in terms[] that contains the prefix,
    // or -1 if there are no words containing the prefix. This search should be
    // implemented using a variation of the binary search algorithm.
    // Performance requirement: O(logn), n is size.
    //
    int firstIndexOf(string prefix) {
        int foundIndex = 0;
        int middleIndex = 0;
        int leastIndex = 0;
        int highestIndex = this -> size - 1;
        int indexTrack = -2;
        for (; highestIndex >= leastIndex; ) {  // binary search
            middleIndex = (highestIndex + leastIndex) / 2;
            if (this -> terms[middleIndex].query == prefix) {
                foundIndex = middleIndex;
                return foundIndex;
            }
            // this checks if the prefix is present.
            if (prefixCheck(this -> terms[middleIndex].query, prefix)) {
                indexTrack = middleIndex;
                break;
            }
            if (this -> terms[middleIndex].query < prefix) {
                leastIndex = middleIndex + 1;
                continue;
            }
            if (this -> terms[middleIndex].query > prefix) {
                highestIndex = middleIndex - 1;
                continue;
            }
        }
        // if a prefix is found then this block executes.
        if (indexTrack != -2) {
            foundIndex = indexTrack;
            // goes to the first position
            // of that prefix
            while (prefixCheck(this -> terms[foundIndex].query, prefix)) {
                foundIndex--;
            }
            foundIndex++;
            return foundIndex;            
        }
        return -1;
    }
    // //
    // // Private member function.
    // // Returns the index of the last word in terms[] that contains the prefix,
    // // or -1 if there are no words containing the prefix. This search should be
    // // implemented using a variation of the binary search algorithm.
    // // Performance requirement: O(logn), n is size.
    // //
    int lastIndexOf(string prefix) {
        int foundIndex = 0;
        int middleIndex = 0;
        int leastIndex = 0;
        int highestIndex = this -> size - 1;
        int indexTrack = -2;
        int lastPos = 0;
        for (; highestIndex >= leastIndex; ) {  // binary search
            middleIndex = (highestIndex + leastIndex) / 2;
            // this block check if prefix is present or not
            if (prefixCheck(this -> terms[middleIndex].query, prefix)) {
                indexTrack = middleIndex;
                break;
            }
            if (this -> terms[middleIndex].query < prefix) {
                leastIndex = middleIndex + 1;
                continue;
            }
            if (this -> terms[middleIndex].query > prefix) {
                highestIndex = middleIndex - 1;
                continue;
            }
        }
        // if prefix found this block executes
        if (indexTrack != -2) {
            foundIndex = indexTrack;
            // goes down to the last index where we can find the prefix
             while (prefixCheck(this -> terms[foundIndex].query, prefix)) {
                lastPos = foundIndex;
                foundIndex++;
            }
            return lastPos;            
        }
        return -1;
    }
    //
    // Private member function.
    // This function sorts the terms array by lexicographic order of the query
    // string.
    // Set sortType to "lex".
    // Performance requirement: O(nlogn), n is size.
    //
    void sortByLexOrder() {
        sort(this -> terms, this -> terms + this -> size, [](const Term &lhs, Term &rhs) { return lhs.query < rhs.query; } );
    }
    //
    // Private member function.
    // This function sorts the terms array by decreasing weight order.
    // Set the sortType to "weight".
    // Performance requirement: O(nlogn), n is size.
    //
    void sortByWeightOrder() {
         sort(this -> terms, this -> terms + this -> size, [](const Term &lhs, Term &rhs) { return lhs.weight > rhs.weight; } );
    }
 public:
    //
    // default constructor:
    //
    // Called automatically by C++ to create a AutocompleteList.
    // When this is called, intialize terms to a nullptr and set size to 0.
    // Set sortType to "none".
    // Performance requirement: O(1)
    //
    AutocompleteList() {
        this -> terms = nullptr;
        this -> size = 0;
        this -> sortType = "none";
    }
    //
    // a second constructor:
    //
    // Parameter passed in determines size of terms.
    // When this is called, allocate memory for n Terms and
    // set size accordingly.
    // Set sortType to "none".
    // Performance requirement: O(1)
    //
    AutocompleteList(int n) {
        this -> terms = new Term[n];
        this -> size = n;
        this -> sortType = "none";
    }
    //
    // a third constructor:
    //
    // Parameter passed in is name of file to read in.
    // This constructor will build Autocomplete list from file.
    // Assume file format is:
    // line 1: "<size>"
    // lines 2 thru size+1: "weight query"
    // The list should be sorted lexicographic order by the query string.
    // Set sortType to "lex".
    // Performance requirement: O(nlogn), n is size.
    //
    AutocompleteList(string filename) {
        ifstream reader(filename);
        string fileLength;
        getline(reader, fileLength);
        int fileSize = stoi(fileLength);
        this -> terms = new Term[fileSize];
        this -> size = fileSize;
        this -> sortType = "lex";
        int curr = 0;
        string tabSpace;
        reader >> this -> terms[curr].weight;
        // removing tabspace by stroing in a variable
        getline(reader, tabSpace, '\t');
        // files ends with a new line so read outside the loop first.
        getline(reader, this->terms[curr].query);
        while (!reader.eof()) { // end of file loop
            curr++;
            reader >> this -> terms[curr].weight; 
            getline(reader, tabSpace, '\t');
            getline(reader, this->terms[curr].query);
        }
        // after storing sortByLexOrder.
        this -> sortByLexOrder(); 
        reader.close();
    }
    //
    // copy constructor:
    //
    // Called automatically by C++ to create an AutocompleteList that contains
    // a copy of an existing AutocompleteList.  Example: this occurs when
    // passing AutocompleteList as a parameter by value.
    // Performance requirement: O(n), n is size.
    //
    AutocompleteList(const AutocompleteList& other) {
        this -> terms = new Term[other.size];
        this -> sortType = other.sortType;
        this -> size = other.size;
        int iterator = 0;
        // copying all the elements of weight and query using a loop
        while (iterator < this -> size) {
            this -> terms[iterator].weight = other.terms[iterator].weight;
            this -> terms[iterator].query = other.terms[iterator].query;
            iterator = iterator + 1;
        }
    }
    //
    // copy operator=
    //
    // Called when you assign one AutocompleteList into another,
    // i.e. this = other;
    // Performance requirement: O(n), n is size.
    //
    AutocompleteList& operator=(const AutocompleteList& other) {
        delete[] terms; // deleting existing memory.
        this -> terms = new Term[other.size];
        this -> sortType = other.sortType;
        this -> size = other.size;
        int iterator = 0;
        // copy all the elements of weight and query using loop.
        while (iterator < this -> size) {
            this -> terms[iterator].weight = other.terms[iterator].weight;
            this -> terms[iterator].query = other.terms[iterator].query;
            iterator = iterator + 1;
        }
        return *this;
    }
    //
    // destructor:
    //
    // Called automatically by C++ to free the memory associated by the Term.
    //
    virtual ~AutocompleteList() {
        if (this -> terms != nullptr) {
            delete[] this -> terms;
        }
    }
    //
    // Public member function.
    // Returns the size of the AutocompleteList.
    // Performance requirement: O(1).
    //
    int getSize() {
        return this->size;
    }
    //
    // Public member function.
    // Returns Term element in AutocompleteList.
    // This gives public access to Terms stored in the AutocompleteList.
    // If i is out of bounds, throw an out_of_range error message:
    // "AutocompleteList: i out of bounds"
    // Note:  This public function does not necessarily fit the design of this
    // abstraction but we are having you write it for testing purposes.
    // Performance requirement: O(1).
    //
    Term& operator[](int i) {
        if (i < 0 || i >= this -> size) {
            throw out_of_range("AutocompleteList: i out of bounds");
        } 
        return this -> terms[i]; 
    }
    // Public member function.
    // Returns an AutocompleteList which stores a list of all Terms that
    // start with the prefix.  The AutocompleteList returned should be sorted
    // in descending order by weight.  Set the returned AutocompleteList's
    // sortType to "weight".
    // If prefix is empty string, return an empty AutocompleteList;
    // If there are no words in the list the start with the prefix, return an
    // empty AutocompleteList.
    // If this AutocompleteList's sortType does not equal "lex", then return
    // an empty AutocompleteList.  In other words, allMatches should only be
    // called on an AutocompleteList that is sorted in lexicographic order by
    // the query string.
    // Performance requirement: O(mlogm+logn), n is size and
    // where m is the number of matching terms.
    //
    AutocompleteList allMatches(string prefix) {
        int numberOfMatchesValue = numberOfMatches(prefix);
        if (prefix == "") { 
            AutocompleteList matches;
            return matches;
        } else if (numberOfMatchesValue <= 0) {
            AutocompleteList matches;
            return matches;
        } else if (this -> sortType != "lex") {
            AutocompleteList matches;
            return matches;
        }
        AutocompleteList matches(numberOfMatchesValue);
        int startPoint = firstIndexOf(prefix);
        int endPoint = lastIndexOf(prefix);
        int iterator = 0;
        // storing the elements from first index of prefix to
        // last index of the prefix.
        while (startPoint <= endPoint) {
            matches.terms[iterator].query = this -> terms[startPoint].query;
            matches.terms[iterator].weight = this -> terms[startPoint].weight;
            iterator++;
            startPoint++;
        }
        matches.sortByWeightOrder();  // sorting them by weight descenind order
        matches.sortType = "weight";
        return matches;  
    }
    // public member function
    // for creative component.
    // sorts the queries in descenind order.
    void sortByLexOrderDesc() {
        sort(this -> terms, this -> terms + this -> size, [](const Term &lhs, Term &rhs) { return lhs.query > rhs.query; } );
    }
    // public member function
    // for creative component.
    // returns the AutocompleteList object which are sorted lexicographic order.
     AutocompleteList creativeOne(string prefix) {
        int numberOfMatchesValue = numberOfMatches(prefix);
        if (prefix == "") {
            AutocompleteList matches;
            return matches;
        } else if (numberOfMatchesValue <= 0) {
            AutocompleteList matches;
            return matches;
        } else if (this -> sortType != "lex") {
            AutocompleteList matches;
            return matches;
        }
        AutocompleteList matches(numberOfMatchesValue);
        int startPoint = firstIndexOf(prefix);
        int endPoint = lastIndexOf(prefix);
        int iterator = 0;
        // storing the elements from first index of prefix to
        // last index of the prefix.
        while (startPoint <= endPoint) {
            matches.terms[iterator].query = this -> terms[startPoint].query;
            matches.terms[iterator].weight = this -> terms[startPoint].weight;
            iterator++;
            startPoint++;
        }
        matches.sortByLexOrder();  // sorting them by lex ascending order
        matches.sortType = "lex ASC";
        return matches;  
    }
    // public member function
    // for creative component.
    // returns the AutocompleteList object which
    // are sorted lexicographic descending order.
    AutocompleteList creativeTwo(string prefix) {
        int numberOfMatchesValue = numberOfMatches(prefix);
        if (prefix == "") {
            AutocompleteList matches;
            return matches;
        } else if (numberOfMatchesValue <= 0) {
            AutocompleteList matches;
            return matches;
        } else if (this -> sortType != "lex") {
            AutocompleteList matches;
            return matches;
        }
        AutocompleteList matches(numberOfMatchesValue);
        int startPoint = firstIndexOf(prefix);
        int endPoint = lastIndexOf(prefix);
        int iterator = 0;
        // storing the elements from first index of prefix to
        // last index of the prefix.
        while (startPoint <= endPoint) {
            matches.terms[iterator].query = this -> terms[startPoint].query;
            matches.terms[iterator].weight = this -> terms[startPoint].weight;
            iterator++;
            startPoint++;
        }
        matches.sortByLexOrderDesc();  // sorting them by lex descending order 
        matches.sortType = "lex DSC";
        return matches;  
    }
    // Public member function.
    // Returns the number of Terms that start with the given prefix.
    // If prefix is empty, return 0.
    // If this AutocompleteList's sortType does not equal "lex",
    // then return 0.
    // Performance requirement: O(logn), n is size.
    //
    int numberOfMatches(string prefix) {
        if (prefix == "") {  // error check
            return 0;
        } else if (this -> sortType != "lex") {  //error check
            return 0;
        }
        int total = 0;
        int firstIndexVal = firstIndexOf(prefix);
        int lastIndexVal = lastIndexOf(prefix);
        if (firstIndexVal == -1) { 
            return 0;
        } else if (lastIndexVal == -1) {
            return 0;
        }
        // formula to get the number of elements that contain prefix.
        total = ((lastIndexVal - firstIndexVal) + 1);
        return total;
    }
    //
    // Public member function.
    // Prints the AutocompleteList.
    // Pad the front of the print with 8 spaces for nicely formatted search:
    // print: "        query, weight".
    // NOTE:  This is also useful for debugging purposes.
    // Performance requirement: O(n), n is size
    //
    void print() {
        int iterator = 0;
        int size = getSize();
        // printing the contents.
        while (iterator < size) {
            cout << "        " << this -> terms[iterator].query 
            << ", " << this -> terms[iterator].weight << endl;
            iterator = iterator + 1;
        }
    }
};