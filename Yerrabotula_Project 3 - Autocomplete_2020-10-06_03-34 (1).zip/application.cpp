//
//  application.cpp
/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 3 - autocomplete
*/
/*
Creative Component: it has three functionalities.
1) first one is to print search results in 
lexicographic order.
2) secone one is to print the search results
in lexicographic descending order.
3) third one is to check for a valid file
if it is a valid file then again
it prompts the user to select options
1 or 2 from creative Component.
how to use it:
step 1: enter the file name of your choice
step 2: type "c". (c is a string here).
step 3: it will give you 3 options to select
step 4: select any option and enter the number 1,2, or 3
step 5: if the input is 1 or 2,
then you need to enter a prefix you want to search
step 6: if the input is 3.
and if the file is valid 
it asks for enter 1 or 2.
if file is invalid application throws an error.
step 7: if the input is 1 or 2,
then you need to enter a prefix you want to search
*/

#include <iostream>
#include "AutocompleteList.h"
#include <string>
#include <fstream>

using namespace std;

// takes the user input and updates the variables
void takeInput(string& userInput, string& nameOfFile) {
    cout << "Enter filename: ";
    getline(cin, nameOfFile);
    cout << "Enter s-search or c-creative search: ";
    getline(cin, userInput);
}
// check for a valid file
bool fileCheck(string& nameOfFile) {
    ifstream infile(nameOfFile);
    if (!infile.is_open()) {
        return false;
    }
    infile.close();
    return true;
}
// prints the basic instructions for creative part.
void creativeInstructions(string& creativeChoice) {
    cout << "Welcome!" << endl;
    cout << "Enter 1 to print the result in";
    cout << " lexicographic order " << endl;
    cout << "Enter 2 to print the result in";
    cout << "lexicographic descending order " << endl;
    cout << " Enter 3 to check if a file is valid or invalid,";
    cout << " file is valid then enter 1 or 2 again." << endl;
    getline(cin, creativeChoice);
    cout << "Type your search below, ";
    cout << "press enter for ";
    cout << " autocomplete (# to stop). " << endl;
}
int main() {
    string userInput;
    string nameOfFile;
    string search;
    string creativeChoice;
    takeInput(userInput, nameOfFile);
    // if userInput is s then do the regular autocomplete
    if (userInput == "s") {
        cout << "Welcome!" << endl;
        cout << "Type your search below, press enter for autocomplete (# to stop)." << endl;
        cout << "Search: ";
        getline(cin, search);
        if (search == "#") { //exit command
            return 0;
        }
        AutocompleteList object(nameOfFile);
        AutocompleteList copyObject;
        while (search != "#") {  // loop until the user enters #
            copyObject = object.allMatches(search);
            copyObject.print();
            cout << "Search: ";
            getline(cin, search);
        }
    } else if (userInput == "c") {  // if userInput is c then do the creative search
    // prints the instructions of creative component.
        creativeInstructions(creativeChoice);
        AutocompleteList object(nameOfFile);
        AutocompleteList copyObject;
        while (search != "#") {  // loop until the user enters #
            if (creativeChoice == "1") {  //1st functionality from instructions
                cout << "Search: ";
                getline(cin, search);
                copyObject = object.creativeOne(search);
                copyObject.print();
            } else if (creativeChoice == "2") {  //2nd functionality from instructions
                cout << "Search: ";
                getline(cin, search);
                copyObject = object.creativeTwo(search);
                copyObject.print();
            } else if (creativeChoice == "3") {  // 3rd functionality from instructions
                if (fileCheck(nameOfFile)) {
                    cout << "Enter 1 to print the result in lexicographic order " << endl;
                     cout << "Enter 2 to print the result in lexicographic descending order " << endl;
                     getline(cin, creativeChoice);
                } else {
                    return 0;
                }
            } else {  // if wrong input for creative choice
                cout << "wrong input value.. exitting.." << endl;
                return 0;
            }
        }
    } else {
        return 0;
    }
    return 0;
}
