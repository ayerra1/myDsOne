/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 5 - priorityqueue
*/

#include <gtest/gtest.h>
#include "priorityqueue.h"
#include <vector>
#include <sstream>
#include <string>
// default constructor integer test
// with data type: int 
TEST(priorityqueue, defaultConstructorInt) {
  priorityqueue < int > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }
}
// default constructor string test
// with data type: string 
TEST(priorityqueue, defaultConstructorString) {
  priorityqueue < string > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }

}
// default constructor char test
// with data type: char
TEST(priorityqueue, defaultConstructorChar) {
  priorityqueue < char > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }

}
// default constructor bool test
// with data type: bool
TEST(priorityqueue, defaultConstructorBool) {
  priorityqueue < bool > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }

}
// default constructor double test
// with data type: double
TEST(priorityqueue, defaultConstructorDouble) {
  priorityqueue < double > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }

}
// default constructor float test
// with data type: float 
TEST(priorityqueue, defaultConstructorFloat) {
  priorityqueue < float > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }
}
// default constructor long int test
// with data type: long int
TEST(priorityqueue, defaultConstructorLongInt) {
  priorityqueue < long int > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }

}
// default constructor long long test
// with data type: long long
TEST(priorityqueue, defaultConstructorLongLong) {
  priorityqueue < long long > p1;
  for (int i = 0; i < 15; i++) {
    EXPECT_EQ(p1.Size(), 0);
  }

}
/**************************************/
// only Size() test
// size() test
// with data type: int(size test).
TEST(priorityqueue, sizeTestInt) {
  priorityqueue < int > p1;
  int counter = 0;
  for (int i = 0; i < 15; i++) {
    p1.enqueue(i + 1, i);
    counter++;
    EXPECT_EQ(p1.Size(), counter);
  }

  vector < int > priorities = {
    5,
    4,
    8,
    2,
    6,
    11,
    8,
    8,
    10,
    20,
    30,
    40,
    50,
    88,
    14,
    58,
    78,
    54,
    12,
    14,
    25,
    156,
    147,
    1558,
    1559,
    1456,
    2354
  };
  // Zero size test 
  priorityqueue < int > p2;
  EXPECT_EQ(p2.Size(), 0);
  // duplicate priority vals
  priorityqueue < int > p3;
  counter = 0;
  int sizeCheck = priorities.size();
  for (int i = 0; i < sizeCheck; i++) {
    p3.enqueue(i, priorities.at(i));
    counter++;
    EXPECT_EQ(p3.Size(), counter);
  }
  // every node has duplicate priority vals
  priorityqueue < int > p4;
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  int sizeCheckOne = prioritiesTwo.size();
  counter = 0;
  for (int i = 0; i < sizeCheckOne; i++) {
    p4.enqueue(i, prioritiesTwo.at(i));
    counter++;
    EXPECT_EQ(p4.Size(), counter);
  }
}

// size() test
// with data type: string(size test).
TEST(priorityqueue, sizeTesString) {
  priorityqueue < string > p1;
  int counter = 0;
  for (int i = 0; i < 15; i++) {
    p1.enqueue("dolres", i);
    counter++;
    p1.enqueue("arnold", i + 1);
    counter++;
    EXPECT_EQ(p1.Size(), counter);
  }
  // Zero size test 
  priorityqueue < string > p2;
  EXPECT_EQ(p2.Size(), 0);

  vector < int > priorities = {
    5,
    4,
    8,
    2,
    6,
    11,
    8,
    8,
    10,
    20,
    30,
    40,
    50,
    88,
    14,
    58,
    78,
    54,
    12,
    14,
    25,
    156,
    147,
    1558,
    1559,
    1456,
    2354
  };

  // duplicate priority vals
  priorityqueue < string > p3;
  counter = 0;
  int sizeCheck = priorities.size();
  for (int i = 0; i < sizeCheck; i++) {
    p3.enqueue("anuragReddy", priorities.at(i));
    counter++;
    EXPECT_EQ(p3.Size(), counter);
  }

  // every node has duplicate priority vals
  priorityqueue < string > p4;
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  int sizeCheckOne = prioritiesTwo.size();
  counter = 0;
  for (int i = 0; i < sizeCheckOne; i++) {
    p4.enqueue("cs251", prioritiesTwo.at(i));
    counter++;
    EXPECT_EQ(p4.Size(), counter);
  }

}

// size() test
// with data type: char(size test).
TEST(priorityqueue, sizeTestChar) {
  priorityqueue < char > p1;
  int counter = 0;
  for (int i = 0; i < 15; i++) {
    p1.enqueue('a', i);
    counter++;
    p1.enqueue('b', i + 1);
    counter++;
    EXPECT_EQ(p1.Size(), counter);
  }

  // Zero size test 
  priorityqueue < char > p2;
  EXPECT_EQ(p2.Size(), 0);

  vector < int > priorities = {
    5,
    4,
    8,
    2,
    6,
    11,
    8,
    8,
    10,
    20,
    30,
    40,
    50,
    88,
    14,
    58,
    78,
    54,
    12,
    14,
    25,
    156,
    147,
    1558,
    1559,
    1456,
    2354
  };
  // duplicate priority vals
  priorityqueue < char > p3;
  counter = 0;
  int sizeCheck = priorities.size();
  for (int i = 0; i < sizeCheck; i++) {
    p3.enqueue('i', priorities.at(i));
    counter++;
    EXPECT_EQ(p3.Size(), counter);
  }

  // every node has duplicate priority vals
  priorityqueue < char > p4;
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  int sizeCheckOne = prioritiesTwo.size();
  counter = 0;
  for (int i = 0; i < sizeCheckOne; i++) {
    p4.enqueue('j', prioritiesTwo.at(i));
    counter++;
    EXPECT_EQ(p4.Size(), counter);
  }
}

// clear constructor integer test
// with data
TEST(priorityqueue, clearTest) {
  priorityqueue < int > p1;
  vector < int > prioritiesOne = {
    100,
    200,
    300,
    500,
    150,
    750,
    250,
    50,
    254,
    859,
    456,
    444,
    854,
    854,
    758,
    984,
    98,
    78,
    75,
    48,
    78,
    85,
    58,
    1,
    2
  };
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  vector < string > valueSet = {
    "dolres",
    "arnold",
    "red",
    "pink",
    "blue",
    "green",
    "orange",
    "blak",
    "white",
    "nine",
    "an",
    "anu",
    "urg",
    "pres",
    "pp",
    "an",
    "b",
    "agh",
    "123",
    "456",
    "45",
    "ghj5",
    "12cbn",
    "df",
    "df",
    "fhj",
    "gnj"
  };
  int sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p1.enqueue(i + 1, prioritiesOne.at(i));
    p1.clear();
    EXPECT_EQ(p1.Size(), 0);
  }
  priorityqueue < int > p2;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p2.enqueue(i + 2, prioritiesTwo.at(i));
    p2.clear();
    EXPECT_EQ(p2.Size(), 0);
  }

  /* using string values in priorityqueue */
  priorityqueue < string > p3;
  sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p3.enqueue(valueSet.at(i), prioritiesOne.at(i));
    p3.clear();
    EXPECT_EQ(p3.Size(), 0);
  }
  priorityqueue < string > p4;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p4.enqueue(valueSet.at(i), prioritiesTwo.at(i));
    p4.clear();
    EXPECT_EQ(p4.Size(), 0);
  }

  /* char vals  test */
  vector < char > charTest = {
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'm',
    'n',
    'o',
    'p',
    'q',
    'r',
    's',
    't',
    'u',
    'v',
    'w',
    'x',
    'y',
    'z',
    'z',
    'z'
  };
  priorityqueue < char > p5;
  sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p5.enqueue(charTest.at(i), prioritiesOne.at(i));
    p5.clear();
    EXPECT_EQ(p5.Size(), 0);
  }
  priorityqueue < char > p6;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p6.enqueue(charTest.at(i), prioritiesTwo.at(i));
    p6.clear();
    EXPECT_EQ(p6.Size(), 0);
  }

  /* Long values test with clear */
  vector < long > longTest = {
    111111,
    222222,
    333333,
    444444,
    444444,
    555555,
    666666,
    777777,
    888888,
    999999
  };
  priorityqueue < long > p7;
  sizeCheck = longTest.size();
  for (int i = 0; i < sizeCheck; i++) {
    p7.enqueue(longTest.at(i), prioritiesOne.at(i));
    p7.clear();
    EXPECT_EQ(p7.Size(), 0);
  }
  priorityqueue < long > p8;
  sizeCheck = longTest.size();
  for (int i = 0; i < sizeCheck; i++) {
    p8.enqueue(longTest.at(i), prioritiesTwo.at(i));
    p8.clear();
    EXPECT_EQ(p8.Size(), 0);
  }

}

// equality operator test
// with all the data types like: int, string, char, long
TEST(priorityqueue, equalityOperatorTest) {
  priorityqueue < int > p1;
  priorityqueue < int > p2;
  vector < int > prioritiesOne = {
    100,
    200,
    300,
    500,
    150,
    750,
    250,
    50,
    254,
    859,
    456,
    444,
    854,
    854,
    758,
    984,
    98,
    78,
    75,
    48,
    78,
    85,
    58,
    1,
    2
  };
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  vector < string > valueSet = {
    "dolres",
    "arnold",
    "red",
    "pink",
    "blue",
    "green",
    "orange",
    "blak",
    "white",
    "nine",
    "an",
    "anu",
    "urg",
    "pres",
    "pp",
    "an",
    "b",
    "agh",
    "123",
    "456",
    "45",
    "ghj5",
    "12cbn",
    "df",
    "df",
    "fhj",
    "gnj"
  };
  int sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p1.enqueue(i + 1, prioritiesOne.at(i));
    p2 = p1;
    EXPECT_EQ(p1 == p2, true);

  }

  sizeCheck = prioritiesTwo.size();
  priorityqueue < int > p3;
  for (int i = 0; i < sizeCheck; i++) {
    p3.enqueue(i + 1, prioritiesTwo.at(i));
    p2 = p3;
    EXPECT_EQ(p3 == p2, true);
  }

  /* empty int objects  */
  priorityqueue < int > p8;
  p1 = p8;
  EXPECT_EQ(p1 == p8, true);

  /* string values test on equals operator */
  priorityqueue < string > p4;
  priorityqueue < string > p6;
  sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p4.enqueue(valueSet.at(i), prioritiesOne.at(i));
    p6 = p4;
    EXPECT_EQ(p6 == p4, true);
  }
  priorityqueue < string > p5;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p5.enqueue(valueSet.at(i), prioritiesTwo.at(i));
    p4 = p5;
    EXPECT_EQ(p4 == p5, true);
  }

  /* empty int objects  */
  priorityqueue < string > p7;
  p5 = p7;
  EXPECT_EQ(p5 == p7, true);

  /* char objects checking */
  vector < char > charTest = {
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'm',
    'n',
    'o',
    'p',
    'q',
    'r',
    's',
    't',
    'u',
    'v',
    'w',
    'x',
    'y',
    'z',
    'z',
    'z'
  };
  priorityqueue < char > p10;
  priorityqueue < char > p11;
  sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p10.enqueue(charTest.at(i), prioritiesOne.at(i));
    p11 = p10;
    EXPECT_EQ(p10.Size(), p11.Size());
    EXPECT_EQ(p10.toString(), p11.toString());
  }
  priorityqueue < char > p12;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p12.enqueue(charTest.at(i), prioritiesTwo.at(i));
    p11 = p12;
    EXPECT_EQ(p12.Size(), p11.Size());
    EXPECT_EQ(p12.toString(), p11.toString());
  }

  /* empty char objects  */
  priorityqueue < char > p13;
  p12 = p13;
  EXPECT_EQ(p12 == p13, true);

  /* long objects checking */

  vector < long > longTest = {
    111111,
    222222,
    333333,
    444444,
    444444,
    555555,
    666666,
    777777,
    888888,
    999999
  };
  priorityqueue < long > p14;
  priorityqueue < long > p15;
  sizeCheck = longTest.size();
  for (int i = 0; i < sizeCheck; i++) {
    p14.enqueue(longTest.at(i), prioritiesOne.at(i));
    p15 = p14;
    EXPECT_EQ(p15 == p14, true);
  }
  priorityqueue < long > p16;
  sizeCheck = longTest.size();
  for (int i = 0; i < sizeCheck; i++) {
    p16.enqueue(longTest.at(i), prioritiesTwo.at(i));
    p15 = p16;
    EXPECT_EQ(p15 == p16, true);
  }

  /* empty long objects  */
  priorityqueue < long > p17;
  p16 = p17;
  EXPECT_EQ(p16 == p17, true);

}

// equals operator test
// with all the data types
TEST(priorityqueue, equalsOperatorTest) {
  priorityqueue < int > p1;
  priorityqueue < int > p2;
  vector < int > prioritiesOne = {
    100,
    200,
    300,
    500,
    150,
    750,
    250,
    50,
    254,
    859,
    456,
    444,
    854,
    854,
    758,
    984,
    98,
    78,
    75,
    48,
    78,
    85,
    58,
    1,
    2
  };
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  vector < string > valueSet = {
    "dolres",
    "arnold",
    "red",
    "pink",
    "blue",
    "green",
    "orange",
    "blak",
    "white",
    "nine",
    "an",
    "anu",
    "urg",
    "pres",
    "pp",
    "an",
    "b",
    "agh",
    "123",
    "456",
    "45",
    "ghj5",
    "12cbn",
    "df",
    "df",
    "fhj",
    "gnj"
  };
  int sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p1.enqueue(i + 1, prioritiesOne.at(i));
    p2 = p1;
    EXPECT_EQ(p1.Size(), p2.Size());
    EXPECT_EQ(p1.toString(), p2.toString());

  }

  sizeCheck = prioritiesTwo.size();
  priorityqueue < int > p3;
  for (int i = 0; i < sizeCheck; i++) {
    p3.enqueue(i + 1, prioritiesTwo.at(i));
    p2 = p3;
    EXPECT_EQ(p3.Size(), p2.Size());
    EXPECT_EQ(p3.toString(), p2.toString());

  }

  /* empty string objects  */
  priorityqueue < int > p8;
  p1 = p8;
  EXPECT_EQ(p1.Size(), p8.Size());
  EXPECT_EQ(p8.toString(), p8.toString());

  /* string values test on equals operator */
  priorityqueue < string > p4;
  priorityqueue < string > p6;
  sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p4.enqueue(valueSet.at(i), prioritiesOne.at(i));
    p6 = p4;
    EXPECT_EQ(p6.Size(), p4.Size());
    EXPECT_EQ(p6.toString(), p4.toString());

  }
  priorityqueue < string > p5;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p5.enqueue(valueSet.at(i), prioritiesTwo.at(i));
    p4 = p5;
    EXPECT_EQ(p4.Size(), p5.Size());
    EXPECT_EQ(p4.toString(), p5.toString());

  }

  /* empty string objects  */
  priorityqueue < string > p7;
  p5 = p7;
  EXPECT_EQ(p5.Size(), p7.Size());
  EXPECT_EQ(p5.toString(), p7.toString());

  /* char objects checking */
  vector < char > charTest = {
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'm',
    'n',
    'o',
    'p',
    'q',
    'r',
    's',
    't',
    'u',
    'v',
    'w',
    'x',
    'y',
    'z',
    'z',
    'z'
  };
  priorityqueue < char > p10;
  priorityqueue < char > p11;
  sizeCheck = prioritiesOne.size();
  for (int i = 0; i < sizeCheck; i++) {
    p10.enqueue(charTest.at(i), prioritiesOne.at(i));
    p11 = p10;
    EXPECT_EQ(p10.Size(), p11.Size());
    EXPECT_EQ(p10.toString(), p11.toString());
  }
  priorityqueue < char > p12;
  sizeCheck = prioritiesTwo.size();
  for (int i = 0; i < sizeCheck; i++) {
    p12.enqueue(charTest.at(i), prioritiesTwo.at(i));
    p11 = p12;
    EXPECT_EQ(p12.Size(), p11.Size());
    EXPECT_EQ(p12.toString(), p11.toString());
  }

  /* empty string objects  */
  priorityqueue < char > p13;
  p12 = p13;
  EXPECT_EQ(p12.Size(), p13.Size());
  EXPECT_EQ(p12.toString(), p13.toString());

  /* long objects checking */

  vector < long > longTest = {
    111111,
    222222,
    333333,
    444444,
    444444,
    555555,
    666666,
    777777,
    888888,
    999999
  };
  priorityqueue < long > p14;
  priorityqueue < long > p15;
  sizeCheck = longTest.size();
  for (int i = 0; i < sizeCheck; i++) {
    p14.enqueue(longTest.at(i), prioritiesOne.at(i));
    p15 = p14;
    EXPECT_EQ(p15.Size(), p14.Size());
    EXPECT_EQ(p15.toString(), p14.toString());
  }
  priorityqueue < long > p16;
  sizeCheck = longTest.size();
  for (int i = 0; i < sizeCheck; i++) {
    p16.enqueue(longTest.at(i), prioritiesTwo.at(i));
    p15 = p16;
    EXPECT_EQ(p15.Size(), p16.Size());
    EXPECT_EQ(p15.toString(), p16.toString());
  }

  /* empty long objects  */
  priorityqueue < long > p17;
  p16 = p17;
  EXPECT_EQ(p16.Size(), p17.Size());
  EXPECT_EQ(p16.toString(), p17.toString());

}

// enqueue  test
// with all the data types
TEST(priorityqueue, enqueueTesting) {
  priorityqueue < int > p1;
  priorityqueue < string > p2;
  vector < int > prioritiesOne = {
    1,
    1,
    2,
    2,
    3,
    4,
    5,
    5,
    6,
    7,
    8,
    9,
    9,
    9,
    10,
    10,
    10,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    100,
    150,
    150,
    200
  };
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  vector < string > valueSet = {
    "dolres",
    "arnold",
    "red",
    "pink",
    "blue",
    "green",
    "orange",
    "blak",
    "white",
    "nine",
    "an",
    "anu",
    "urg",
    "pres",
    "pp",
    "an",
    "b",
    "agh",
    "123",
    "456",
    "45",
    "ghj5",
    "12cbn",
    "df",
    "df",
    "fhj",
    "gnj"
  };

  // 50+ asserts
  string tostringCheck = "";
  int counter = 0;
  for (int i = 0; i < prioritiesOne.size(); i++) {
    p1.enqueue(i + 1, prioritiesOne.at(i));
    string temp = to_string(prioritiesOne.at(i));
    tostringCheck += temp;
    tostringCheck += " value: ";
    tostringCheck += to_string(i + 1);
    tostringCheck += "\n";
    counter++;
    EXPECT_EQ(p1.Size(), counter);
    EXPECT_EQ(tostringCheck, p1.toString());
  }

  // string datat type with enqueue 
  counter = 0;
  tostringCheck = "";
  //50+ asserts
  for (int i = 0; i < prioritiesTwo.size(); i++) {
    p2.enqueue(valueSet.at(i), prioritiesOne.at(i));
    string temp = to_string(prioritiesOne.at(i));
    tostringCheck += temp;
    tostringCheck += " value: ";
    tostringCheck += valueSet.at(i);
    tostringCheck += "\n";
    counter++;
    EXPECT_EQ(p2.Size(), counter);
    EXPECT_EQ(tostringCheck, p2.toString());
  }

}
// enqueue  test
// with all the data types
TEST(priorityqueue, tostring) {
  priorityqueue < int > p1;
  priorityqueue < string > p2;
  vector < int > prioritiesOne = {
    1,
    1,
    2,
    2,
    3,
    4,
    5,
    5,
    6,
    7,
    8,
    9,
    9,
    9,
    10,
    10,
    10,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    100,
    150,
    150,
    200
  };
  vector < int > prioritiesTwo = {
    100,
    100,
    200,
    200,
    300,
    300,
    500,
    500,
    150,
    150,
    20,
    20,
    250,
    250,
    1750,
    1750,
    1350,
    1350,
    1555,
    1555,
    3000,
    3000,
    42,
    42
  };
  vector < string > valueSet = {
    "dolres",
    "arnold",
    "red",
    "pink",
    "blue",
    "green",
    "orange",
    "blak",
    "white",
    "nine",
    "an",
    "anu",
    "urg",
    "pres",
    "pp",
    "an",
    "b",
    "agh",
    "123",
    "456",
    "45",
    "ghj5",
    "12cbn",
    "df",
    "df",
    "fhj",
    "gnj"
  };
  // 50+ asserts
  string tostringCheck = "";
  int counter = 0;
  for (int i = 0; i < prioritiesOne.size(); i++) {
    p1.enqueue(i + 1, prioritiesOne.at(i));
    string temp = to_string(prioritiesOne.at(i));
    tostringCheck += temp;
    tostringCheck += " value: ";
    tostringCheck += to_string(i + 1);
    tostringCheck += "\n";
    counter++;
    EXPECT_EQ(p1.Size(), counter);
    EXPECT_EQ(tostringCheck, p1.toString());
  }
  // string datat type with toString 
  counter = 0;
  tostringCheck = "";
  //50+ asserts
  for (int i = 0; i < prioritiesTwo.size(); i++) {
    p2.enqueue(valueSet.at(i), prioritiesOne.at(i));
    string temp = to_string(prioritiesOne.at(i));
    tostringCheck += temp;
    tostringCheck += " value: ";
    tostringCheck += valueSet.at(i);
    tostringCheck += "\n";
    counter++;
    EXPECT_EQ(p2.Size(), counter);
    EXPECT_EQ(tostringCheck, p2.toString());
  }
}
// Tests to test the begin and next functions function
TEST(priorityqueue, beginAndNext) {
  priorityqueue < string > p1;
  priorityqueue < string > p2;
  vector < string > values(100);
  vector < int > priorities(100);
  string str1;
  string value = "Anurag";
  int priority = 0;
  int itr = 0;
  while (itr < 20) {
    p1.enqueue(value, priority);
    values[itr] = value;
    priorities[itr] = priority;
    str1 += to_string(priority) + " value: " + value + "\n";
    value[0] = value[0] + 1;
    priority++;
    itr++;
  }
  p1.begin();
  string setOne, setTwo;
  string valSet;
  int priori = 0;
  int i = 0;
  for (int i = 0; i < 100; i++) {
    while (p1.next(valSet, priori)) {
      setOne += to_string(priorities[i]) + " value: " + values[i] + "\n";
      setTwo += to_string(priori) + " value: " + valSet + "\n";
      EXPECT_EQ(setOne, setTwo);
      i++;
      setOne = "";
      setTwo = "";
    }
  }
}



