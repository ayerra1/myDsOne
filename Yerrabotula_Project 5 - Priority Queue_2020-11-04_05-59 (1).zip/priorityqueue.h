/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 5 - priorityqueue
*/
#pragma once
#include <iostream>
#include <sstream>
#include <set>
using namespace std;

template < typename T >
  class priorityqueue {
    private:
      struct NODE {
        int priority; // used to build BST
        T value; // stored data for the p-queue
        bool dup; // marked true when there are duplicate priorities
        NODE * parent; // links back to parent
        NODE * link; // links to linked list of NODES with duplicate priorities
        NODE * left; // links to left child
        NODE * right; // links to right child
      };
    NODE * root; // pointer to root node of the BST
    int size; // # of elements in the pqueue
    NODE * curr; // pointer to next item in pqueue (see begin and next)
      //
      // helper function for operator=:
      //
      // enques all the current object data to otherObj.
    void _equalsOperator(NODE * curr) {
      if (curr != NULL) {
            enqueue(curr -> value, curr -> priority);
      // do something
      if (curr -> link != NULL) {
        NODE * temp = curr -> link;
        for (;temp != NULL;) {
          enqueue(temp -> value, temp -> priority);
          temp = temp -> link;
        }
      }
      /* passes left node as parameter follows pre-order*/
      _equalsOperator(curr -> left);
      /* passes right node as parameter  follow pre-order*/
      _equalsOperator(curr -> right);
      } 
      
    }
     // helper function for next() and dequeue():
     // returns the maximum priority present in the tree  
    int maxPriority(NODE * root) {
      NODE * tempPtr = root;
      NODE * prevPtr = tempPtr;
      for (;tempPtr != NULL;) {
        prevPtr = tempPtr;
        tempPtr = tempPtr -> right;
      }
      return prevPtr -> priority;
    }
     // helper function for operator==:
     // compares the duplicate values present in the and returns a boolean
     // if same returns true else false.
    bool linklistEquality(const NODE * currentObj, const NODE * otherObj) const {
      if (currentObj -> dup == true && otherObj -> dup == true) {
          if (otherObj -> dup == true) {
               for (;currentObj != NULL && otherObj != NULL;) {
          if (currentObj -> value != otherObj -> value) {
            return false;
          }
          currentObj = currentObj -> link;
          otherObj = otherObj -> link;
        }
          }
      }
      return true;
    }
    // helper function for operator==:
    // uses the approach described in the slides of AVL trees.
    // compares the nodes present in two trees and returns a boolean
    // if same true, else false.
    bool _equality(const NODE * currentObj,
      const NODE * otherCurr) const {
      if (currentObj == NULL) {
          if (otherCurr == NULL) {
              return true;
          }
      } else if (currentObj == NULL) {
        return false;
      } else if (otherCurr == NULL) {
        return false;
      } else {
         // comparing each and every attribute of two nodes.
         // attributes are: value, priority, dup, left, right
        if ((currentObj -> value == otherCurr -> value) &&
          (currentObj -> priority == otherCurr -> priority) &&
          (currentObj -> dup == otherCurr -> dup)) {
              if ((linklistEquality(currentObj, otherCurr))) {
                  if ((_equality(currentObj -> left, otherCurr -> left))) {
                  if ((_equality(currentObj -> right, otherCurr -> right))) {
                      return true;
                  }
              }
              }
        } else {
          return false;
        }
      }
    }
    // helper function for dequeue and peek:
    // implementation and working of this function same as begin() function.
    // instead of using private variable curr, we are using a temp ptr.
    NODE * temperoryBegin() {
      NODE * tempPtr = this -> root;
      NODE * prevPtr = tempPtr;
      for (;tempPtr != nullptr;) {
        prevPtr = tempPtr;
        tempPtr = tempPtr -> left;
      }
      return prevPtr;
    }
   // helper function for clear():
   // this function uses the post order traversal
   // to delete all the nodes one by one. 
   void _clear(NODE * curr) {
      if (curr == NULL) {
        return;
      } else {
        _clear(curr -> left); // sends left child
        _clear(curr -> right); // sends right child
        // if the curet node has duplicates
        if (curr -> link != NULL) {
          NODE * prev = curr;
          NODE * temp = curr -> link;
          // traverse through link list and delete them.
          while (temp != NULL) {
            if (prev -> link == NULL) {
              this -> size = this -> size - 1;
              delete temp;
              break;
            }
            prev -> link = temp -> link;
            this -> size = this -> size - 1;
            delete temp;
            temp = prev -> link;
          }

        }
        this -> size = this -> size - 1;
        delete curr;
      }
   }
    // helper function for next():
   // if the current node does not have any right child
   // then go up until Travel up the tree using 
   //the parent pointer until you see a node 
   //which is the left child of its parent.  
   bool _nextHelperTwo() {
      NODE * currParent = curr -> parent;
      if (currParent -> left == curr) {
        curr = currParent;
        return true;
      } else {
        NODE * parTwo = curr -> parent;
        for (;parTwo != parTwo -> parent -> left;) {
          parTwo = parTwo -> parent;
        }
        curr = parTwo -> parent;
        return true;
      }
    }
     // helper function for next():
   // if the current node does have any right child
   /*Go to the right substree and return the
   node with the minimum priority in the right subtree. */
    bool _nextHelperOne() {
      curr = curr -> right;
      NODE * tempPtr = this -> curr;
      NODE * prevPtr = NULL;
      // finds the least priority node.
      if (tempPtr != NULL) {
        for (; tempPtr != NULL;) {
          prevPtr = tempPtr;
          tempPtr = tempPtr -> left;
        }
        this -> curr = prevPtr;
      }
      return true;
    }
    // helper function for toString()
    // this follows in order traversal becuase 
    // to write them to string stream in them
    // sorted order.
    void _recursion(NODE * curr, string & str) {
      stringstream writeString;
      if (curr == NULL) {
        return;
      } else {
        _recursion(curr -> left, str); // sends the left child
        writeString << curr -> priority << " value: " << curr -> value << endl;
        str = str + writeString.str();
        if (curr -> link != NULL) {
          stringstream newstream;
          NODE * temp = curr -> link;
          for (;temp != NULL;) {
            newstream << temp -> priority << " value: " << temp -> value << endl;
            temp = temp -> link;
          }
          str = str + newstream.str();
        }
        _recursion(curr -> right, str); // sends the right child
      }
    }
    // helper function for enqueue
    // creates a new NODE
    // insterts it at the end of duplicate list
    // this function is called if a node has a duplicate
     void _enqueHelper(NODE** prev, NODE** currentNode, int priority, T value) {
          NODE * newNode = new NODE();
          newNode -> priority = priority;
          newNode -> value = value;
          newNode -> dup = true;
          newNode -> parent = (*currentNode);
          newNode -> left = nullptr;
          newNode -> right = nullptr;
          (*prev) -> link = newNode;
          newNode -> link = nullptr;
          (*prev) -> dup = true;
    }  
    // helper function for enqueue
    // creates a new NODE in the original enques
    // will pass it as reference and will update it values.
    // inserts it at the end of the regular tree depending upon the priority
    void _enqueHelperTwo(int priority, T value, NODE** prev, NODE** newNode) {
      (*newNode) -> priority = priority;
      (*newNode) -> value = value;
      (*newNode) -> dup = false;
      (*newNode) -> parent = (*prev);
      (*newNode) -> link = nullptr;
      (*newNode) -> left = nullptr;
      (*newNode) -> right = nullptr;
    }
    // helper function for dequeue:
    // executed when the node has a duplicate value.
    // and that node is not the root node.
     void _deqHelper(NODE**temp, NODE* currentNode) {
         // if it's not the root.
         if (*temp != root) {
            if (*temp == (*temp) -> parent -> left) {
          (*temp) -> parent -> left = currentNode -> link;
        } else {
            (*temp) -> parent -> right = currentNode -> link;
        }
      }
    }
     // helper function for dequeue:
    // executed when the node is a right child of it's parent.
     void _deqHelperTwo(NODE** currentNode) {
        // if the node has a right child 
        if ((*currentNode) -> right != nullptr) {
        (*currentNode) -> parent -> right = (*currentNode) -> right;
        (*currentNode) -> right -> parent = (*currentNode) -> parent;
    } else {
        (*currentNode) -> parent -> right = nullptr;
    }
    }
     // helper function for dequeue:
    // executed when the node is the left child of it's parent.
    void _deqHelperThree(NODE** currentNode) {
        // if the node has a right child.
         if ((*currentNode) -> right != nullptr) {
        (*currentNode) -> parent -> left = (*currentNode) -> right;
        (*currentNode) -> right -> parent = (*currentNode) -> parent;
    } else {
        (*currentNode) -> parent -> left = nullptr;
    }
    }
     // dequeue helper function
    // connects the duplicates nodes 
    void deqHelperDupli(NODE** currentPtr) {
         (*currentPtr) -> link -> parent =  (*currentPtr) -> parent;
          (*currentPtr) -> link -> left =  (*currentPtr) -> left;
         (*currentPtr) -> link -> right =  (*currentPtr) -> right;
    }
    public:
      //
      // default constructor:
      //
      // Creates an empty priority queue.
      // O(1)
      //
      priorityqueue() {
        // TO DO: write this function.
        this -> root = nullptr;
        this -> size = 0;
        this -> curr = nullptr;
      }
    //
    // operator=
    //
    // Clears "this" tree and then makes a copy of the "other" tree.
    // Sets all member variables appropriately.
    // O(n), where n is total number of nodes in custom BST
    //
    priorityqueue & operator = (const priorityqueue & other) {
      this -> clear();
      _equalsOperator(other.root);
      return *this;
    }
    //
    // clear:
    //
    // Frees the memory associated with the priority queue but is public.
    // O(n), where n is total number of nodes in custom BST
    //
    void clear() {
        this -> curr = this -> root;
        _clear(curr);
        this -> root = NULL;
        this -> curr = NULL;
      }
      //
      // destructor:
      //
      // Frees the memory associated with the priority queue.
      // O(n), where n is total number of nodes in custom BST
      //
      ~priorityqueue() {
        this -> clear();
      }
    //
    // enqueue:
    //
    // Inserts the value into the custom BST in the correct location based on
    // priority.
    // O(logn+m), where n is number of unique nodes in tree and m is number of
    // duplicate priorities
    //
    void enqueue(T value, int priority) {
      NODE * prev = nullptr;
      NODE * currentNode = this -> root;
      this -> size++;
      // part1: searching till we find a spot to insert
      // uses regular binary search algorithm
      bool flag = false;
      for (;currentNode != nullptr; ) {
        if (priority ==  currentNode -> priority) {
           flag = true;
           break;
        }
        if (priority < currentNode -> priority) {
          prev = currentNode;
          currentNode = currentNode -> left;
        } else {
          prev = currentNode;
          currentNode = currentNode -> right;
        }
      }
      // this block is executed when the seearching encounters a duplicate
      if (flag == true) {
          if (priority ==  currentNode -> priority) {
          NODE * temp = currentNode;
          for (;temp != nullptr;) {
            prev = temp;
            temp = temp -> link;
          }
          // this function creates a new NODE
          // and connects the new node to the previous link
          // and returns the function
          _enqueHelper(&prev, &currentNode, priority, value);
          return;
        }
        if (priority < currentNode -> priority) {
          prev = currentNode;
          currentNode = currentNode -> left;
        } else {
          prev = currentNode;
          currentNode = currentNode -> right;
        }
      }
      // no duplicate founds
      // create a new node insert where prev is pointing
      // considering the priority value
      // insert the new node as appropriate child of prev.
      NODE * newNode = new NODE();
      // sets the new node value, priority, dup, parent values.
      _enqueHelperTwo(priority, value, &prev, &newNode);
       if (prev == nullptr) {
        this -> root = newNode;
      } else if (priority < prev -> priority) {
        prev -> left = newNode;
      } else if (priority > prev -> priority) {
        prev -> right = newNode;
      }
    }
    //
    // dequeue:
    //
    // returns the value of the next element in the priority queue and removes
    // the element from the priority queue.
    // O(logn + m), where n is number of unique nodes in tree and m is number of
    // duplicate priorities
    //
    T dequeue() {
        T valueOut;
        // creating a pointer to point to the least priority node
        NODE * currentPtr = temperoryBegin();
        // the current pointer is not null
        if (currentPtr != nullptr) {
            // setting value
            valueOut = currentPtr -> value;
            this -> size-- ;
            // if the current node need to remove is the last node
            if (currentPtr -> priority == maxPriority(root)) {
                // if the maxPriority node has duplicates
                if (currentPtr -> link != nullptr) {
                    root = currentPtr -> link;
                    delete (currentPtr);
                // if doesn't have duplicates    
                } else {
                    root = nullptr;
                    delete(currentPtr);
                    clear();
                    currentPtr = nullptr;
                }
            } // if the curr node is not the maxPriority node.
            // and has duplicates.
            else if (currentPtr -> link != nullptr) {
                if (currentPtr->dup) {
                    NODE * temp = currentPtr;
                if (temp -> parent == nullptr) {
                    currentPtr -> link -> parent = nullptr;
                    root = currentPtr -> link;
                } else if (temp -> parent != nullptr) {
                     _deqHelper(&temp, currentPtr);
                }
                deqHelperDupli(&currentPtr);
                delete(currentPtr);
                currentPtr = nullptr;
                }
            } // if the current node is at root.
            else if (currentPtr -> parent == nullptr) {
                if (currentPtr == root) {
                    root = root -> right;
                    root -> parent = nullptr;
                    delete(currentPtr);
                    currentPtr = nullptr;
                }
            }
            // if the curren node is a left child of it's parent
            else if (currentPtr == currentPtr -> parent -> left) {
               _deqHelperThree(&currentPtr);
                delete(currentPtr);
                currentPtr = nullptr;
            } // if the current node is a right child of it's parent.
            else {
                _deqHelperTwo(&currentPtr);
                delete(currentPtr);
                currentPtr = nullptr;
            }
            return valueOut;
        }
    }
    // Size:
    //
    // Returns the # of elements in the priority queue, 0 if empty.
    // O(1)
    //
    int Size() {
      return this -> size;
    }
    //
    // begin
    //
    // Resets internal state for an inorder traversal.  After the
    // call to begin(), the internal state denotes the first inorder
    // node; this ensure that first call to next() function returns
    // the first inorder node value.
    //
    // O(logn), where n is number of unique nodes in tree and m is number of
    // duplicate priorities
    //
    // Example usage:
    //    pq.begin();
    //    while (tree.next(value, priority)) {
    //      cout << priority << " value: " << value << endl;
    //    }
    //    cout << priority << " value: " << value << endl;
    void begin() {
      // TO DO: write this function.
      if (this -> root == nullptr) {
        return;
      }
      NODE * tempPtr = this -> root;
      NODE * prevPtr = tempPtr;
      for (; tempPtr != nullptr;) {
        prevPtr = tempPtr;
        tempPtr = tempPtr -> left;
      }
      this -> curr = prevPtr;
    }
    //
    // next
    //
    // Uses the internal state to return the next inorder priority, and
    // then advances the internal state in anticipation of future
    // calls.  If a value/priority are in fact returned (via the reference
    // parameter), true is also returned.
    //2
    // False is returned when the internal state has reached null,
    // meaning no more values/priorities are available.  This is the end of the
    // inorder traversal.
    //
    // O(?) - hard to say.  But approximately O(logn + m).  Definitely not O(n).
    //
    // Example usage:
    //    pq.begin();
    //    while (tree.next(value, priority)) {
    //      cout << priority << " value: " << value << endl;
    //    }
    //    cout << priority << " value: " << value << endl;
    //
    bool next(T & value, int & priority) {
      // if the current pointer is null then
      //tree is finished return false,    
      if (this -> curr == NULL) {
        return false;
      }
      // setting value and priority
      value = this -> curr -> value;
      priority = this -> curr -> priority;
      // if the current node is the maxPriority node.
      if (curr -> priority == maxPriority(root)) {
        if (curr -> link != nullptr) {
            if (curr -> dup) {
                curr = curr -> link;
                return true;
            }
        } else {
          return false;
        }
      }
      // If the node has duplicates
      if (curr -> link != nullptr) {
        curr = curr -> link;
        return true;
        // if the node doesn't have duplicates
      } else if (curr -> link == nullptr) {
          if (curr -> dup == true) {
              curr = curr -> parent;
          }
      }
      // If the right subtree of the node is not empty
      if (curr -> right != NULL) {
          return _nextHelperOne();
      // If the right subtree of the node  empty      
      } else if (curr -> right == NULL) {
            return _nextHelperTwo();
      }
      return true;
    }
    //
    // toString:
    //
    // Returns a string of the entire priority queue, in order.  Format:
    // "1 value: Ben
    //  2 value: Jen
    //  2 value: Sven
    //  3 value: Gwen"
    //
    string toString() {
      string str = "";
      NODE* current = this -> root;
      _recursion(current, str);
      return str;
    }
    //
    // peek:
    //
    // returns the value of the next element in the priority queue but does not
    // remove the item from the priority queue.
    // O(logn + m), where n is number of unique nodes in tree and m is number of
    // duplicate priorities
    //
    T peek() {
      T valueOut;
      NODE * currentPtr = temperoryBegin();
      valueOut = currentPtr -> value;
      return valueOut;
    }
    //
    // ==operator
    //
    // Returns true if this priority queue as the priority queue passed in as
    // other.  Otherwise returns false.
    // O(n), where n is total number of nodes in custom BST
    //
    bool operator == (const priorityqueue & other) const {
      return ((this -> size == other.size) &&
        _equality(this -> root, other.root));
    }
    //
    // getRoot - Do not edit/change!
    //
    // Used for testing the BST.
    // return the root node for testing.
    //
    void * getRoot() {
      return root;
    }
  };