//tests.cpp
/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 4 - DNA
*/
#include <gtest/gtest.h>
#include "dna.h"
TEST(dna, constructor) {
    dna d;
    EXPECT_EQ(d.size(), 2);
    int count = 0;
    while (count < 100) {
        for (int i = 0; i < d.size(); i++) {
        EXPECT_EQ(d.at(i), 'X');
    }
    EXPECT_EQ(d.toString(), "XX");
    EXPECT_EQ(d.isLinked(), true);
    count++;
    }
}
TEST(dna, secondConstructor) {
    // checking with nonempty string
    string dnastr = "AGATC";
    dna d(dnastr);
    EXPECT_EQ(d.isLinked(), true);
    EXPECT_EQ(d.toString(), dnastr);
    EXPECT_EQ(d.size(), dnastr.length());
    // checking for non empty string in LOOP
    // by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 90
    string dnastr1 = "TCCACATTTTTAAGAAT";
    for(int i =0,  j = 65; i < 30; i++) {  // 90
        dna d1(dnastr1);
        EXPECT_EQ(d1.isLinked(), true);  // 30
         EXPECT_EQ(d1.toString(), dnastr1);  // 30
        EXPECT_EQ(d1.size(), dnastr1.length());  // 30
        dnastr1 += j; // adding character to back 
        j++;
    }
    // checking with space string in LOOP
    // by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 90
    string dnastr2 = " ";
    for(int i =0, j = 65; i < 30; i++) {  // 90
        dna d2(dnastr2);  // everytime this becomes unique
        EXPECT_EQ(d2.isLinked(), true);  // 30
        EXPECT_EQ(d2.toString(), dnastr2);  // 30
        EXPECT_EQ(d2.size(), dnastr2.length());  // 30
        dnastr2 += j;  // adding character.
        j++;
    }
    // checking for non empty string with special character in LOOP
    // by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 90
    string dnastr3 = "**ANU**";
    for (int i = 0, j = 65; i < 30; i++) {  // 90
        dna d3(dnastr3);  // everytime this becomes unique
        EXPECT_EQ(d3.isLinked(), true);  // 30
        EXPECT_EQ(d3.toString(), dnastr3);  // 30
        EXPECT_EQ(d3.size(), dnastr3.length());  // 30
        dnastr3 += j;  // adding character to end of string in loop.
        j++;
    }
    dna d5("");
    EXPECT_EQ(d5.toString(), "");
    EXPECT_EQ(d5.isLinked(), true);
    EXPECT_EQ(d5.size(), 0);
}
TEST(dna, size) {
    // size with large text.
    string dnastr1 = "AGAAAGTGATGAGGGAGATAGTTAGGAAAAGGTTAAATTAAATTAAGAAAAATTATCTATCTATCTATCTATCAAGATAGGGAATAATGGAGAAATAAAGAAAGTGGAAAAAGATCAGATCAGATCTTTGGATTAATGGTGTAATAGTTTGGTGATAAAAGAGGTTAAAAAAGTATTAGAAATAAAAGATAAGGAAATGAATGAATGAGGAAGATTAGATTAATTGAATGTTAAAAGTTAA";
    // checking the size of  non empty long string.
    // by adding character to the back of string.
    // loop iterate: 50 times.
    // total assertions = 50
    for(int i =0, j = 65; i < 50; i++) { 
        dna d1(dnastr1);  // everytime new constructor with unique string.
        EXPECT_EQ(d1.size(), dnastr1.length()); 
        dnastr1 += j;  // adding character to the back.
        j++;
    }
    // checking size of an empty string initially then
    // by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 30
    string dnastr2 = "";
    for(int i =0, j = 65; i < 30; i++) { // 90
        dna d2(dnastr2);  // everytime new constructor with unique string.
        EXPECT_EQ(d2.size(), dnastr2.length());
        dnastr2 += j;  // adding char back
        j++;
    }
    // checking size of a single char string initially then
    // by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 30
    string dnastr3 = "Z";
    for (int i = 0 , j = 97; i < 30; i++) { // 90
        dna d3(dnastr3);  // everytime new constructor with unique string.
        EXPECT_EQ(d3.size(), dnastr3.length()); // 30
        dnastr3 += j;  // adding char back.
        j++;
    }
}
TEST(dna, toString) {
    // TO DO: write lots of assertions here.
    string dnastr1 = "AAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBCCCCCCCCCCCCCCCCCDDDDDDDE";
    // comparing the passing string with the return val of toString.
    // THEN IN LOOP by adding character to the back of string.
    // loop iterate: 50 times.
    // total assertions = 50
    for(int i =0, j = 65; i < 50; i++) {
        dna d1(dnastr1);
        EXPECT_EQ(d1.toString(), dnastr1);
        dnastr1 += j;
        j++;
    }
    // comparing by passing empty string with the return val of toString.
    // THEN IN LOOP by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 30
    string dnastr2 = "";
    for(int i =0, j = 85; i < 30; i++) { // 90
        dna d2(dnastr2);  // everytime new constructor with unique string
        EXPECT_EQ(d2.toString(), dnastr2); // 30
        dnastr2 += j;
        j++;
    }
    // comparing by passing string of single char with the return val of toString.
    // THEN IN LOOP by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 30
    string dnastr3 = "Z";
    for (int i = 0 , j = 97; i < 30; i++) { // 90
        dna d3(dnastr3);  // everytime new constructor with unique string
        EXPECT_EQ(d3.toString(), dnastr3); // 30
        dnastr3 += j;
        j++;
    }
    // comparing by passing space string with the return val of toString.
    // THEN IN LOOP by adding character to the back of string.
    // loop iterate: 30 times.
    // total assertions = 30
    string dnastr4 = " ";
    for (int i = 0 , j = 97; i < 30; i++) { // 90
        dna d4(dnastr4);  // everytime new constructor with unique string
        EXPECT_EQ(d4.toString(), dnastr4); // 30
        dnastr4 += j;
        j++;
    }
}
TEST(dna, at) {
    // checking with return val of at with single character string
    string dnastr1 = "A";
    dna d1(dnastr1);
    EXPECT_EQ(d1.at(0), dnastr1[0]);
    // edge case error test checking.
    ASSERT_THROW(d1.at(-1), out_of_range);
    //199 characters.
    // checking with return val of at with long string
    string dnastr2 = "GGGGAATATGGTTATTAAGTTAAAGAGAAAGAAAGATGTGGGTGATATTAATGAATGAATGAATGAATGAATGAATGAATGTTATGATAGAAGGATAAAAATTAAATAAAATTTTAGTTAATAGAAAAAGAATATATAGAGATCAGATCTATCTATCTATCTTAAGGAGAGGAAGAGATAAAAAAATATAATTAAGGAA";
    dna d2(dnastr2);
    // iterationg through string index and comapring .at() return val.
    for (int i =0; i < dnastr2.size(); i++ ) {
        EXPECT_EQ(d2.at(i), dnastr2[i]);
        ASSERT_THROW(d2.at(d2.size()), out_of_range);  // error check
    }
    string dnastr3 = "";
    dna d3(dnastr3);
    ASSERT_THROW(d3.at(0), out_of_range);  // error check
}
TEST(dna, clear) {
    // passing empty string
    // and using clear
    string dnastr1 = "";
    dna d1(dnastr1);
    d1.clear();
    EXPECT_EQ(d1.isLinked(), true);
    EXPECT_EQ(d1.toString(), "");
    EXPECT_EQ(d1.size(), 0);
    // passing non empty string
    // using clear and checking
    // repeat in loop
    // iterations: 50
    // total assets: 150
    string dnastr2 = "CCCGATCAGATCAGATCGTCAGTCAGTCAGTTTTTTTTTTTATACTATACCC";
    for (int i = 0 , j = 97; i < 50; i++) {
        dna d2(dnastr2);
        d2.clear();
        EXPECT_EQ(d1.isLinked(), true);
        EXPECT_EQ(d1.toString(), "");
        EXPECT_EQ(d1.size(), 0);
        dnastr2 += j; 
        j++;
        dnastr2 += j;
        j++;
    }
}
TEST(dna, copyConstructor) {
    string dnastr1 = "AGAAAGTGATGAGGGAGATAGTTAGGAAAAGGTTAAATTAAATTAAGAAAAATTATCTATCTATCTATCTATCAAGATAGGGAATAATGGAGAAATAAAGAAAGTGGAAAAAGATCAGATCAGATCTTTGGATTAATGGTGTAATAGTTTGGTGATAAAAGAGGTTAAAAAAGTATTAGAAATAAAAGATAAGGAAATGAATGAATGAGGAAGATTAGATTAATTGAATGTTAAAAGTTAA";
    // using equal opertaor
    // everytime d1 updates and dna d2 = d1
    // iterations: 30;
    // total assertions: 120.
    for (int i = 0, j = 85; i < 30; i++) {
         dna d1(dnastr1);
         dna d2 = d1;
        EXPECT_EQ(d2.size(), d1.size());
        EXPECT_EQ(d2.toString(), d1.toString());
        EXPECT_EQ(d2.isLinked(), d1.isLinked());
        EXPECT_EQ(d2.at(i), d2.at(i));
        dnastr1 += j++;
    }
    // check copy constructor with empty string.
    string dnastr2 = "";
    dna d3(dnastr2);
    dna d4 = d3;
    EXPECT_EQ(d4.size(), d3.size());
    EXPECT_EQ(d4.toString(), d3.toString());
    EXPECT_EQ(d4.isLinked(), d3.isLinked());
}
TEST(dna, equalsOperator) {
    string dnastr1 = "AAAATTTTCCCCCCATAHNSBMARTTTTTTTCGATATATACTATATTATATATATATCAGTCAGTCAGT";
    dna d2("AAAAGGGGAAATTTTTAACCCC");  // d2 has this small string
    // using equal opertaor
    // now previous contents of d2 will be erased
    // d2 and d1 will have same contents.
    // everytime d1 updates and d2 = d1
    // iterations: 30;
    // total assertions: 120.
    for (int i = 0, j = 72; i < 30; i++) {
        dna d1(dnastr1);
        d2 = d1;
        EXPECT_EQ(d2.size(), d1.size());
        EXPECT_EQ(d2.toString(), d1.toString());
        EXPECT_EQ(d2.isLinked(), d1.isLinked());
        EXPECT_EQ(d2.at(i), d2.at(i));
        dnastr1 += j++;
    }
    // checking with empty string.
    string dnastr2 = "";
    dna d3(dnastr2);
    dna d4("GGGTTCCV");
    d4 = d3;
    EXPECT_EQ(d4.size(), d3.size());
    EXPECT_EQ(d4.toString(), d3.toString());
    EXPECT_EQ(d4.isLinked(), d3.isLinked());
}
TEST(dna, operatorEquality) {
    string dnastr2 = "";
    dna d3(dnastr2);  // d3 has an empty string
    dna d4("GGGTTCCV");
    d4 = d3;  // equalsOperator
    EXPECT_EQ(d4==d3, true);  // now checking if it's true or not.
   string dnastr1 = "AAAAATTTTTTGGGGAAATHATGGAAGGAGAABABJAJBAACAAAGHGVHNGVNBVSHSVTTTTTTT";
   // updating the objects in the loop
   // and comparing the return value.
   // total assertions : 100 (unique).
   for (int i = 0, j = 65; i < 100; i++) {
       dna d1(dnastr1);
       dna d2 = d1;
        EXPECT_EQ(d2==d1, true);
        dnastr1 += j;
        j++;
   }
   // edge case: if two obj not equal
   // return false.
   string dnastr3 = "AATGFATAC";
   dna d5(dnastr3);
   dna d6("AAtGGAHJ");
   EXPECT_EQ(d5==d6, false);
}
TEST(dna, splice) {
    // check splice when both begin and end of the string
    // contains the target string.
    string dnaTarget = "CAG";
    string original =  "CAGGGGCAGTTTTGTGTGTHTABCDECAG";
    dna target(dnaTarget);
    dna d1(original); // begin and end same
    bool check = d1.splice(target);
    EXPECT_EQ(d1.size(), original.length() - dnaTarget.length());
    EXPECT_EQ(d1.isLinked(), true);
    EXPECT_EQ(check, true);
    // check splice when middle of the string 
    // contains the target string.
    dnaTarget = "AGATC";
    original = "GTCAGTCAGTTCTCTCTTAGBTAGATCAGATAGTACAGATCBTAGCAGATCTATC";
    dna target2(dnaTarget);
    dna d2(original);
    check = d2.splice(target2);
    EXPECT_EQ(d2.size(), original.length() - dnaTarget.length());
    EXPECT_EQ(d2.isLinked(), true);
    EXPECT_EQ(check, true);
    // check splice when end of the 
    // string contains target string.
    dnaTarget = "TACTACC";
    original = "GTCGTCGTCGTCGAGATCCAGTCAGTTCAGTGDACTGACTACTACC"; 
    dna target3(dnaTarget);
    dna d3(original);
    check = d3.splice(target3);
    EXPECT_EQ(d3.size(), original.length() - dnaTarget.length());
    EXPECT_EQ(d3.isLinked(), true);
    EXPECT_EQ(check, true);
    // check splice 
    // by passing an empty string in target.
    // edge case check: splice func return false
    dnaTarget = "";
    original = "AGATAGATAGATCAGTTACTATAC";
    dna target4(dnaTarget);
    dna d4(original);
    check = d4.splice(target4);
    EXPECT_EQ(d4.size(), original.length() - dnaTarget.length());
    EXPECT_EQ(d4.isLinked(), true);
    EXPECT_EQ(check, false); // splice returns false.
    // CHECK for non existing and non empty target string.
    // edge case check: splice func return false
    dnaTarget = "ABCD";
    original = "GTCAGTCAGT";
    dna target5(dnaTarget);
    dna d5(original);
    check = d5.splice(target5);
    EXPECT_EQ(d5.isLinked(), true);
    EXPECT_EQ(check, false);
    // check for non existing and 
    // non empty target  in superlong string.
    // edge case check: splice func return false
    dnaTarget = "ABCD";
    original = "AGAAAGTGATGAGGGAGATAGTTAGGAAAAGGTTAAATTAAATTAAGAAAAATTATCTATCTATCTATCTATCAAGATAGGGAATAATGGAGAAATAAAGAAAGTGGAAAAAGATCAGATCAGATCTTTGGATTAATGGTGTAATAGTTTGGTGATAAAAGAGGTTAAAAAAGTATTAGAAATAAAAGATAAGGAAATGAATGAATGAGGAAGATTAGATTAATTGAATGTTAAAAGTTAAAGAAAGTGATGAGGGAGATAGTTAGGAAAAGGTTAAATTAAATTAAGAAAAATTATCTATCTATCTATCTATCAAGATAGGGAATAATGGAGAAATAAAGAAAGTGGAAAAAGATCAGATCAGATCTTTGGATTAATGGTGTAATAGTTTGGTGATAAAAGAGGTTAAAAAAGTATTAGAAATAAAAGATAAGGAAATGAATGAATGAGGAAGATTAGATTAATTGAATGTTAAAAGTTAA";
    dna target8(dnaTarget);
    dna d8(original);
    check = d8.splice(target8);
    EXPECT_EQ(d8.isLinked(), true);
    EXPECT_EQ(check, false);
    // check for empty target string in superlong
    // edge case check: splice func return false
    dnaTarget = "";
    original = "AGAAAGTGATGAGGGAGATAGTTAGGAAAAGGTTAAATTAAATTAAGAAAAATTATCTATCTATCTATCTATCAAGATAGGGAATAATGGAGAAATAAAGAAAGTGGAAAAAGATCAGATCAGATCTTTGGATTAATGGTGTAATAGTTTGGTGATAAAAGAGGTTAAAAAAGTATTAGAAATAAAAGATAAGGAAATGAATGAATGAGGAAGATTAGATTAATTGAATGTTAAAAGTTAAAGAAAGTGATGAGGGAGATAGTTAGGAAAAGGTTAAATTAAATTAAGAAAAATTATCTATCTATCTATCTATCAAGATAGGGAATAATGGAGAAATAAAGAAAGTGGAAAAAGATCAGATCAGATCTTTGGATTAATGGTGTAATAGTTTGGTGATAAAAGAGGTTAAAAAAGTATTAGAAATAAAAGATAAGGAAATGAATGAATGAGGAAGATTAGATTAATTGAATGTTAAAAGTTAA";
    dna target9(dnaTarget);
    dna d9(original);
    check = d9.splice(target9);
    EXPECT_EQ(d9.size(), original.length() - dnaTarget.length());
    EXPECT_EQ(d9.isLinked(), true);
    EXPECT_EQ(check, false);
    // REPEAT SPLICE IN LOOP for small string.
    dnaTarget = "AGT";
    original = "AGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGTAGT";
    dna target6(dnaTarget);
    dna d6(original);
    check = d6.splice(target6); 
    while(check) {
        EXPECT_EQ(d6.isLinked(), true);
        EXPECT_EQ(check, true);
        check = d6.splice(target6);
    }
    // repeat splice in loop large string.
    dnaTarget = "TATC";
    original = "TATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCAGATAGATCAGTCAGTCAGTAGTCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATCTATC";
    dna target7(dnaTarget);
    dna d7(original);
    check = d7.splice(target7);
    while(check) {
        EXPECT_EQ(d7.isLinked(), true);
        EXPECT_EQ(check, true);
        check = d7.splice(target7);
    }
    // repeat splice in loop for a non existing and non empty target.
    // in a superlong file.
    dnaTarget = "XYZ";
    original = "TCTAGTCTAGTCTAGTCTAGTCTAGACTTGTCGCTGACTCCGAGAAGATCCTAACATTAACCAATTCCCCCTAGTCTGAGGCACGGTTACCGATCGGGTTAATGGATCTCTCACCGTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTTTTTTTCTGATAGATAGATAGATAGATAGATAGATAGATAGATAGATAGATAGATAGATAGATAAACGTGTAACTGTAATAATCCGCCCGAAAAAACTGATCTTAGGGTTGCGGCATCTGCACGTGACAGTGTGCTACTGTTAGATAGAGGGATCAAACGAGGTTGCAAGGATTATCTCCGTGCTCGATAAGACACAGCCGGTTGCGGGCTGCTTCCTCTGGATCCAATGCAGCCGTACGTACACCGTAGAGCAAATTTAGTGGTAAAGGAACTTGCTCAAACACTACGGCTTCGGGCTACTGTTGGCGCCGGTTGGGGATCCCATTCAACGCTGGCCCTTTCGCTATGGTTCGGTGATTTTACACCGAAGCGAACCTTGAACCGTGGATTTCGGGTGTCCTCCGTTTTTAGGTACTGCGTGCAGACATGGGCACCTGCCATAGTGCGATCAGCCAGAATCCATTGTATGGGAGTTGGACTCGTTTGAATTTACCGGAAACCTCATGCTTGGTCTGTAGTCTGTCTGTCTGTCTGTCTGTCTGTCTGT";
    dna target10(dnaTarget);
    dna d10(original);
    check = d10.splice(target10);
    while(check) {
        EXPECT_EQ(d10.isLinked(), true);
        EXPECT_EQ(check, true);
        check = d10.splice(target7);
    }
}

