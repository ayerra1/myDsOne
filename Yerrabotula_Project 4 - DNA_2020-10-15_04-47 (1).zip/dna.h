//
// dna.h
//
//
/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 4 - DNA
*/

#pragma once

#include <iostream>
#include <string>

using namespace std;

class dna {
private:
    //
    // This implementation is a doubly-linked structure.  The nodes are structs
    // called Nucleotides.  Size could keep track of how many Nucleotides are
    // currently in the list.  front should always point to the first
    // Nucleotide and back should point to the last one.
    struct Nucleotide {
        char value;
        Nucleotide *next;
        Nucleotide *prev;
    };
    int Size;
    Nucleotide *front;
    Nucleotide *back;
    
    //
    // findFirst: (private)
    //
    // Searches dna for the first copy of the sequence target, returning a
    // pointer to that occurrence or nullptr if the target sequence isn't
    // present.
    // Performance requirement:  this function doesn't have a set Big O target,
    // but should not time out on test cases and be reasonable.
    //
    Nucleotide * findFirst(dna target) {
      Nucleotide * node = nullptr;
      Nucleotide * curr = front;
      int index = 0;
      if (this -> Size == 0 || target.size() == 0) {
        return node;
      }
      node = front;
      int targetSize = target.size();
      bool match = true;
      int pos = 0;
      // if the dnastr and the target has same size 
      // then this block executes and compares
      // each val in node by traversing.
      if (Size == target.size()) {
        if (node -> value == target.at(0)) {
          int charFound = 0;
          Nucleotide * tempTwo = node -> next;
          for (int i = 1; i < target.size(); i++) {
            if (tempTwo -> value == target.at(i)) {
              charFound = charFound + 1;
            }
            tempTwo = tempTwo -> next;
          }
          if (charFound == target.size()) {
            return node;
          }
          return nullptr;
        }
      }
      Nucleotide * temp = nullptr;
      bool found = true;
      // compares
      // each val in node by traversing.
      while (curr != nullptr) {
        if (curr -> value == target.at(0)) {
          node = curr;
          temp = curr;
          int iterOne = 0;
          int charFoundThree = 0;
          while (iterOne < target.size()) {
            if (temp -> value == target.at(iterOne)) {
              charFoundThree = charFoundThree + 1;  //if character matches.
            }
            temp = temp -> next;
            if (temp == nullptr) {
              found = false;
              bool foundTwo = true;
              Nucleotide * temp1 = back;
              int iterTwo = targetSize - 1;
              int charFoundTwo = 0;
              while (iterTwo >= 0) {
                if (temp1 -> value == target.at(iterTwo)) {
                  charFoundTwo = charFoundTwo + 1;  //if character matches.
                }
                temp1 = temp1 -> prev;
                iterTwo--;
              }
              if (charFoundTwo == target.size()) {
                node = temp1 -> next;
                return node;
              }
              break;
            }
            iterOne++;
          }
          if (charFoundThree == target.size()) {
            return node;
          }
        }
        curr = curr -> next;
        found = true;
      }
      node = nullptr;
      return node;
    }
public:
    //
    // default constructor:
    //
    // Called automatically by C++ to create an empty dna object with two
    // Nucleotides, each with the value of 'X'.
    //

    dna() {
        Nucleotide* firstNode = new Nucleotide;
        Nucleotide* secondNode = new Nucleotide;
        firstNode -> prev = nullptr;
        firstNode -> value = 'X';
        firstNode -> next = secondNode;
        secondNode -> prev = firstNode;
        secondNode -> value = 'X';
        secondNode -> next = nullptr;
        front = firstNode;
        back = secondNode;
        Size = 2;
    }
    //
    // second constructor:
    //
    // Produces a new strand of nucleotides spelled out in the sequence given
    // by str.
    // Performance requirement: O(n)
    //
    dna(const string& str) {
        int counter = 0;
        // looping to find the size manually.
        while (str[counter] != '\0') {
            counter++;
        }
        Size = counter;
        if (Size == 0) {
            front = nullptr;
            back = nullptr;
        } else {
            Nucleotide* node = new Nucleotide;
            Nucleotide *prevNode = nullptr;
            int iter = 0;
            // looping to arrange the linked list sequence.
            while (iter < Size) {
              if ( iter == 0) {
                node -> prev = nullptr;
                node -> value = str[iter];
                node -> next = nullptr;
                front = node;
                back = node;
              prevNode = node;
              } else {
                 Nucleotide* otherNode = new Nucleotide;
                 prevNode -> next = otherNode;
                 otherNode -> prev = prevNode;
                 otherNode -> value = str[iter];
                 otherNode -> next = nullptr;
                 back = otherNode;
                 prevNode = prevNode -> next;
              }
              iter++;
            }
        }
    }
    //
    // copy constructor:
    //
    // Called automatically by C++ to create a dna object that contains a copy
    // of an existing dna object.
    // Performance requirement: O(n)
    //
    dna(const dna& other) {
        string temp = other.toString();
        this -> Size = other.Size;
        if (this -> Size == 0) {
           this -> front = nullptr;
           this -> back = nullptr;
        } else {
            Nucleotide* node = new Nucleotide;
            Nucleotide *prevNode = nullptr;
            int iter = 0;
            // looping to arrange it in a sequence.
            while (iter < Size) {
              if ( iter == 0) {
                node -> prev = nullptr;
                node -> value = temp[iter];
                node -> next = nullptr;
                this -> front = node;
                this -> back = node;
                prevNode = node;
              } else {
                 Nucleotide* otherNode = new Nucleotide;
                 prevNode -> next = otherNode;
                 otherNode -> prev = prevNode;
                 otherNode -> value = temp[iter];
                 otherNode -> next = nullptr;
                 this -> back = otherNode;
                 prevNode = prevNode -> next;
              }
              iter++;
            }
        }
    }
    //
    // destructor:
    //
    // Called automatically by C++ to free the memory associated by
    // the dna object.
    // Performance requirement: O(n)
    //
    virtual ~dna() {
        clear();
    }
    //
    // clear:
    //
    // Frees all memory in the chain of nucleotides in the dna obeject.  This
    // function should also set front, back, and Size, appropriately.
    // Performance requirement: O(n)
    //
    void clear() {
        Nucleotide *temp = front;
        // traversing and deleting
        while(front != nullptr) {
          temp = front -> next;
          delete front;
          Size--;
          front = temp;
        }
       front = nullptr; 
       back = nullptr;
    }
    //
    // operator=
    //
    // Called when you assign one dna object into another, i.e. this = other;
    // Performance requirement: O(n)
    //
    dna& operator=(const dna& other) {
      this -> clear();  //calling clear before copying.
      string temp = other.toString();
      this -> Size = other.Size;
        if (this -> Size == 0) {
           this -> front = nullptr;
           this -> back = nullptr;
        } else {
            Nucleotide* node = new Nucleotide;
            Nucleotide* prevNode = nullptr;
            int iter = 0;
            // setting linked list seq after deleting previous contents
            while (iter < Size) {
              if ( iter == 0) {
                node -> prev = nullptr;
                node -> value = temp[iter];
                node -> next = nullptr;
                this -> front = node;
                this -> back = node;
                prevNode = node;
              } else {
                 Nucleotide* otherNode = new Nucleotide;
                 prevNode -> next = otherNode;
                 otherNode -> prev = prevNode;
                 otherNode -> value = temp[iter];
                 otherNode -> next = nullptr;
                 this -> back = otherNode;
                 prevNode = prevNode -> next;
              }
              iter++;
            }
        }
        return *this;  // TO DO: update this.
    }
    //
    // size:
    //
    // Returns the # of Nucleotides currently in the dna strand.
    // Performance requirement: O(1)
    //
    int size() const {
        return this->Size;  // TO DO: update this.
    }
    //
    // at(i):
    //
    // Returns a reference to the ith Nucleotide's value, which allows
    // you to read (access) or write (modify) this value.  If i is out of
    // bounds, an exception is thrown.
    // Performance requirement: O(n)
    //
    char& at(int i) {
        // error check.
        if (i < 0) {
            throw out_of_range("dna: i out of bound");
        }
        if (i >= Size) {
            throw out_of_range("dna: i out of bound");
        }
        // looping through list until i found.
        // and returning val associated wit it.
        Nucleotide* tempPtr = front;
        for (int pos = 0; tempPtr != nullptr; pos++) {
            if (pos == i) {
                return tempPtr -> value;
            }
            tempPtr = tempPtr -> next;
        }
        char out = '0';
        return out;  // TO DO: update this.
    }
    
    //
    // toString:
    //
    // Returns a string spelling out the contents of the dna sequence.
    // Performance requirement: O(n)
    //
    string toString() const {
        Nucleotide *tempPtr = NULL;
        tempPtr = front;
        string dnaSeq = "";
        // traversing
        while (tempPtr != NULL) {
            dnaSeq += tempPtr -> value;
            tempPtr = tempPtr -> next;
        }
        return dnaSeq;  // TO DO: update this.
    }
    //
    // operator==
    //
    // This operator determines how you define equality between two operators.
    // In this function, you should compare other and this.  The two objects
    // should be considered equal if they have the same sequence of values and
    // in the same order.
    // Performance requirement: O(n)
    //
    bool operator==(const dna& other) const {
        // setting two temptrs to this obj front
        // and other obj front.
        Nucleotide *tempPtrOne = this -> front;
        Nucleotide *tempPtrTwo = other.front;
        if (this -> Size != other.Size) {
            return false;
        }
        for ( ;tempPtrOne != nullptr || tempPtrTwo != nullptr; ) {
            if (tempPtrOne -> value != tempPtrTwo -> value) {
                return false;
            }
            tempPtrOne = tempPtrOne -> next;
            tempPtrTwo = tempPtrTwo -> next;
        }
        return true;  // TO DO: update this.
    }
    //
    // splice:
    //
    // Removes the first copy of the sequence in target that appears in the
    // dna sequence of current object.  This requires the linked structure to
    // be properly re-wired after removal.
    // Performance requirement: this function doesn't have a set Big O target,
    // but should not time out on test cases and be reasonable.
    //
    bool splice(dna target) {
        int error = 0;
        if (Size == 0) {
           error++;
        }
        if (error > 0) {  // error check
            return false;
        }
        Nucleotide *temp = findFirst(target);
        Nucleotide *nextTemp = nullptr;
        if (temp == nullptr) {  
            error++;
        }
        if (error > 0) {  // error check
            return false;
        }
        if (temp == front) {  // edge case check
            int iter = 0;
            // when target is in front of list.
            while (iter < target.size()) {
                nextTemp = front -> next;
                temp = nextTemp;
                delete front;
                Size = Size - 1;
                front = nextTemp;
                if (Size == 0) {
                front = nullptr;
                back = nullptr;
                nextTemp = nullptr;
                return true;
                }
                iter = iter + 1;
            }
            Nucleotide* prevPtr = front;
            prevPtr -> prev = nullptr;
        } else {
            // when target is in middle or last.
            Nucleotide *curr = temp->prev;
            Nucleotide* newPtr = temp;
            Nucleotide* traversePtr = nullptr;
            int iterTwo = 0;
            while (iterTwo < target.size()) {
                traversePtr = temp -> next;
                temp = traversePtr;
                delete newPtr;
                Size = Size - 1;
                newPtr = traversePtr;
                iterTwo = iterTwo + 1;
            }
            if (temp == nullptr) { //edge case check
                curr -> next = nullptr;
            } else {
                curr -> next = temp;
                temp -> prev = curr;
            }
        }
        return true;
    }
    //
    // isLinked()
    //
    // Checks if a strand is linked correctly.  This is provided for you.
    // You should use it to test your linked structure often.
    // Performance requirement: O(n)
    //
    bool isLinked() {
        Nucleotide* start = front;
        // If we're at the start of a strand,
        // we should not have a previous pointer.
        if (start != nullptr && start->prev != nullptr) {
            return false;
        }
        // Walk the list, ensuring at each point that the next/prev pointers
        // are consistent with one another.
        for (Nucleotide* curr = start; curr != nullptr; curr = curr->next) {
            if (curr->next != nullptr && curr->next->prev != curr) return false;
            if (curr->prev != nullptr && curr->prev->next != curr) return false;
        }
        return true;
    }
};
