//
//  application.cpp
//
/*
Name: Anurag Reddy Yerrabotula
Course Number: CS 251
Assignment: Project 4 - DNA
*/
#include <iostream>
#include <fstream>
#include <vector>
#include "dna.h"
using namespace std;
// determines the dna thing (AGATC,ETC)
struct dnaStrands {
  string names;
  int valFound;
  int commaVal;
};
// determines the people.
struct member {
  string names;
  vector < int > values;
  string tempName;
};
/* string parsing using lab approach 2. */
void stcHelper(string& STR, string& firstLine);
/* this function determine the dnaStrands 
arguements: firstline from databasefile, and a vector of struct.
*/
void strandCheck(string & firstLine, vector < dnaStrands > & strTypes);
/* this function stores  the people data 
arguements: vector of strings that manipulates people's data, and a vector of struct.
used lab2 approach for string parsing.
*/
void memberData(vector < string > & initialLines, vector < member > & members);
/* this function checks for the match after splcing with dna obj.
arguements: vector of member structs and vector of dnaStrands structs
used lab2 approach for string parsing.
*/
void checkForMatch(vector < member > & members, vector < dnaStrands > & strTypes);
int main() {
  string firstFile;
  string secondFile;
  int firstPos = 1;
  int zeroPos = 0;
  cout << "Welcome to the DNA Profiling App!" << endl;
  cout << "Enter database file: ";
  getline(cin, firstFile);
  cout << "Enter dna file: ";
  getline(cin, secondFile);
  // read file
  string firstLine;
  ifstream inFile(firstFile);
  getline(inFile, firstLine);
  vector < dnaStrands > strTypes;
  // determine the dnastrand.
  strandCheck(firstLine, strTypes);
  // get member information
  string line;
  vector < string > initialLines;
  getline(inFile, line);
  // read the rest of file.
  while (!inFile.eof()) {
    initialLines.push_back(line);
    getline(inFile, line);
  }
  // storing member data
  vector < member > members;
  memberData(initialLines, members);
  cout << endl << "Searching database..." << endl;
  fstream input(secondFile);
  string dnastr;
  input >> dnastr;
  int iterSix = 0;
  // splicing the function and checking for a match.
  while (iterSix < strTypes.size()) {
    dna d(dnastr);
    while (d.splice(strTypes[iterSix].names)) {
      strTypes[iterSix].valFound++;
    }
    iterSix++;
  }
  checkForMatch(members, strTypes);  // checks and prints the information
  return 0;
}
//  string parsing using lab2 approach.
void stcHelper(string& STR, string& firstLine) {
        int zeroPos = 0;
        int firstPos = 1;
        size_t idx = firstLine.find(',');
        STR = firstLine.substr(zeroPos, idx);
        firstLine = firstLine.substr(idx + firstPos, firstLine.size() - firstPos);
 }
/* this function determine the dnaStrands 
arguements: firstline from databasefile, and a vector of struct.
used lab2 approach for string parsing.
*/
void strandCheck(string & firstLine, vector < dnaStrands > & strTypes) {
   int firstPos = 1;
   int zeroPos = 0;
  firstLine += ',';
  size_t position = firstLine.find(',');
  firstLine = firstLine.substr(position + firstPos, firstLine.size() - firstPos);
  int counter = 0;
  int iterOne = 0;
  // looping to check for comma count.
  while (iterOne < firstLine.size()) {
    if (firstLine[iterOne] == ',') {
      counter++;
    }
    iterOne++;
  }
  int iterTwo = 0;
  // extracting and updating the firstLine
  // pusing back to a vector.
  while (iterTwo < counter) {
    string STR;
    stcHelper(STR, firstLine);
    strTypes.push_back({
      STR,
      zeroPos
    });
    iterTwo++;
  }
}
/* this function stores  the people data 
arguements: vector of strings that manipulates people's data, and a vector of struct.
used lab2 approach for string parsing.
*/
void memberData(vector < string > & initialLines, vector < member > & members) {
  int iterThree = 0;
  int zeroPos = 0;
  int firstPos = 1;
  string names = "";
  while (iterThree < initialLines.size()) {
    member object;
    size_t position = initialLines[iterThree].find(',');
    // finding the names present in file.
    names = initialLines[iterThree].substr(zeroPos, position);
    object.names = names;
    names = "";
    string number = initialLines[iterThree].substr(position + firstPos, initialLines[iterThree].size() - firstPos);
    number += ',';
    int iterFour = 0;
    int counter = 0;
    // looping through string
    // until find a comma
    // and increment counter.
    while (iterFour < number.size()) {
      if (number[iterFour] == ',') {
        counter++;
      }
      iterFour++;
    }
    // looping through string
    // until find a comma
    // and extracting the name and number.
    int iterFive = 0;
    while (iterFive < counter) {
      string num;
      stcHelper(num, number);
      int newNum = stoi(num);
      object.values.push_back(newNum);
      iterFive++;
    }
    members.push_back(object);
    iterThree++;
  }
}
/* this function checks for the match after splcing with dna obj.
arguements: vector of member structs and vector of dnaStrands structs
used lab2 approach for string parsing.
*/
void checkForMatch(vector < member > & members, vector < dnaStrands > & strTypes) {
  bool detected = false;
  int iterSeven = 0;
  // checks for match and prints the valid message.
  while (iterSeven < members.size()) {
    bool founded = true;
    int iterEight = 0;
    while (iterEight < strTypes.size()) {
      if (members[iterSeven].values[iterEight] != strTypes[iterEight].valFound) {
        founded = false;
        break;
      }
      iterEight++;
    }
    if (founded == true) {
      cout << "DNA match: " << members[iterSeven].names << endl;
      detected = true;
    }
    iterSeven++;
  }
  if (detected == false) {
    cout << "No match." << endl;
  }
}